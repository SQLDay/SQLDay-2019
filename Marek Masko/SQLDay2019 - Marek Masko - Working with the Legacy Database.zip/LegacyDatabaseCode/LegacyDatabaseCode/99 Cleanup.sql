USE master;
GO

DROP TRIGGER IF EXISTS LoginAuditTrigger ON ALL SERVER;
GO

DROP DATABASE IF EXISTS TameTheBeast;
GO

USE [msdb]
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'CommandLog Cleanup', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'DatabaseBackup - SYSTEM_DATABASES - FULL', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'DatabaseBackup - USER_DATABASES - DIFF', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'DatabaseBackup - USER_DATABASES - FULL', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'DatabaseBackup - USER_DATABASES - LOG', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'DatabaseIntegrityCheck - SYSTEM_DATABASES', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'DatabaseIntegrityCheck - USER_DATABASES', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'IndexOptimize - USER_DATABASES', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'Output File Cleanup', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'DatabaseUserMonitor', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'DatabaseTriage', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'DatabaseTriageQuick', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'DatabaseUsageStats', @delete_unused_schedule=1
GO

EXEC msdb.dbo.sp_delete_job @job_name = 'DatabaseTableSizeMonitoring', @delete_unused_schedule=1
GO
