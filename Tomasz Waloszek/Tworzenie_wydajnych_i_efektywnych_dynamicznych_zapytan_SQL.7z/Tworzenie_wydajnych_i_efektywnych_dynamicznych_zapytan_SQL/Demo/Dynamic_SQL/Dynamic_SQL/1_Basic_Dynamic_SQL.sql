USE AdventureWorks
GO 

SET STATISTICS IO ON;
SET STATISTICS TIME ON; 
SET NOCOUNT ON;



/*  Proste zastosowanie Dymanicznego SQL */

DECLARE @sqlCommand nvarchar(1000) 
DECLARE @columnList varchar(75)		-- Zmienna zawieraj�ca list� kolumn
DECLARE @city varchar(75)			-- Zmienna zawieraj�ca wyszukiwane miasto

SET @columnList = 'AddressLine1, City'
SET @city = 'Berlin'
SET @sqlCommand = 'SELECT ' + @columnList + ' FROM Person.Address WHERE City = ''' +  @city + CHAR(39)

PRINT @SqlCommand;

EXEC (@sqlCommand);
GO 











/*Parsowanie zapyta� */

--Standard SQL 

SELECT & FROM Person.Person;


--Dynamic SQL 

DECLARE @sql_command NVARCHAR(MAX);
SELECT @sql_command = 'SELECT & FROM Person.Person;';
EXEC (@sql_command);
go







/* Triki i Dobre praktyki */

-- Chcemy wyszuka� List� numer�w telefon�w do Pa� o imieniu Anna i typ Cell

DECLARE @Sql_Command VARCHAR(MAX) = ''; -- Zmienna zawieraj�ca polecenie SQL 
DECLARE @First_Name VARCHAR(50) = 'Ana'; -- Imi� - pole obligatoryjne podawane w formularzu. 
DECLARE @Phone_Number_Type VARCHAR(10) = 'Cell'; -- Pole opcjonalne podawane w formularzu
SELECT @Sql_Command = 
'
SELECT
	P.FirstName,
	P.LastName,
	PPh.PhoneNumber,
	PNT.Name
FROM Person.Person AS P
INNER JOIN Person.PersonPhone AS PPh
ON P.BusinessEntityID = PPh.BusinessEntityID
INNER JOIN Person.PhoneNumberType AS PNT
ON PPh.PhoneNumberTypeID = PNT.PhoneNumberTypeID
WHERE P.FirstName = ''' + @First_Name + '''
	AND PNT.Name = ''' + @Phone_Number_Type + '''
	'

--PRINT @Sql_Command; 
EXEC (@Sql_Command);
GO











--Co w przypadku gdy u�ytkownik nie poda typy telefony?

DECLARE @Sql_Command VARCHAR(MAX) = ''; -- Zmienna zawieraj�ca polecenie SQL 
DECLARE @First_Name VARCHAR(50) = 'Ana'; -- Imi� - pole obligatoryjne podawane w formularzu. 
DECLARE @Phone_Number_Type VARCHAR(10) = NULL; -- Pole opcjonalne podawane w formularzu
SELECT @Sql_Command = 
'
SELECT
	P.FirstName,
	P.LastName,
	PPh.PhoneNumber,
	PNT.Name
FROM Person.Person AS P
INNER JOIN Person.PersonPhone AS PPh
ON P.BusinessEntityID = PPh.BusinessEntityID
INNER JOIN Person.PhoneNumberType AS PNT
ON PPh.PhoneNumberTypeID = PNT.PhoneNumberTypeID
WHERE P.FirstName = ''' + @First_Name + '''
	AND PNT.Name = ''' + @Phone_Number_Type + '''
	'


PRINT @Sql_Command;  
EXEC (@Sql_Command);
GO










--Zabezpieczmy nasz kod przed takimi przypadkami

DECLARE @Sql_Command VARCHAR(MAX) = ''; -- Zmienna zawieraj�ca polecenie SQL 
DECLARE @First_Name VARCHAR(50) = 'Ana'; -- Imi� - pole obligatoryjne podawane w formularzu. 
DECLARE @Phone_Number_Type VARCHAR(10) = NULL; -- Pole opcjonalne podawane w formularzu
SELECT @Sql_Command = 
'
SELECT
	P.FirstName,
	P.LastName,
	PPh.PhoneNumber,
	PNT.Name
FROM Person.Person AS P
INNER JOIN Person.PersonPhone AS PPh
ON P.BusinessEntityID = PPh.BusinessEntityID
INNER JOIN Person.PhoneNumberType AS PNT
ON PPh.PhoneNumberTypeID = PNT.PhoneNumberTypeID
WHERE P.FirstName = ''' + @First_Name + '''
';

IF @Phone_Number_Type IS NOT NULL -- dodawaj warunek tylko wtedy gdy zosta� podany typ telefony.
BEGIN
	SELECT @Sql_Command = @Sql_Command +
	'
	AND PNT.Name = ''' + @Phone_Number_Type + '''
	';
END

PRINT @Sql_Command; 
EXEC (@Sql_Command);
GO






/*******************************************************************/
-- Na co warto zwr�ci� uwag�!!






-- Pami�taj, �e w czasie pisania kodu jego cz�ci tekstowe nie s� sprawdzane. Wykonywane jest to dopiero w czasie wykonywania: 


DECLARE @Sql_Command VARCHAR(MAX);
SELECT @Sql_Command = 'SELLECT TOP 17 * FROM Person.Person';

PRINT @Sql_Command;
EXEC (@Sql_Command);
GO













--Pami�taj by odpowiednio rozdziela� elementy kodu

DECLARE @Sql_Command VARCHAR(MAX);
DECLARE @Table_Name VARCHAR(100);
SELECT @Table_Name = 'Person.Person';
SELECT @Sql_Command = 'SELECT TOP 10 * FROM' + @Table_Name;

PRINT @Sql_Command;
EXEC (@Sql_Command);
GO













-- Pami�taj o odpowiednich typach danych

DECLARE @sql VARCHAR(10);
SET @sql = CONVERT(VARCHAR(10), CURRENT_TIMESTAMP, 112) +
			'_' + REPLACE(RIGHT(CONVERT(NVARCHAR, CURRENT_TIMESTAMP, 120), 8), ':','');

select  @sql;
GO 







DECLARE @sql VARCHAR(20);
SET @sql = CONVERT(VARCHAR(20), CURRENT_TIMESTAMP, 112) +
			'_' + REPLACE(RIGHT(CONVERT(NVARCHAR, CURRENT_TIMESTAMP, 120), 8), ':','');

SELECT  @sql;
GO 




