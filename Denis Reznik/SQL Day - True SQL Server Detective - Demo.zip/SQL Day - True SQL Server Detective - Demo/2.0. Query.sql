USE VeryImportantDatabase
GO

SELECT * FROM Numbers