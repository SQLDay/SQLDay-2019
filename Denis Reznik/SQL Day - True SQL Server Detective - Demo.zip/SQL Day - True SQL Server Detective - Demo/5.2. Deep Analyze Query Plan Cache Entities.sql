USE StackOverflow
GO

DECLARE @planHandle1 varbinary(64) = 0x06000B006B34A309008DB09EDD01000001000000000000000000000000000000000000000000000000000000;
DECLARE @planHandle2 varbinary(64) = 0x06000B006B34A309D0576E2ADE01000001000000000000000000000000000000000000000000000000000000;
DECLARE @planHandle3 varbinary(64) = 0x06000B006B34A3098042D26FDE01000001000000000000000000000000000000000000000000000000000000;

SELECT plan1.attribute, plan1.value, plan2.value, plan3.value, plan1.is_cache_key 
FROM sys.dm_exec_plan_attributes(@planHandle1) plan1
INNER JOIN sys.dm_exec_plan_attributes(@planHandle2) plan2
	ON plan1.attribute = plan2.attribute
INNER JOIN sys.dm_exec_plan_attributes(@planHandle3) plan3
	ON plan1.attribute = plan3.attribute
GO