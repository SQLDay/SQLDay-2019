use master;
go

create database ProstyModel;
go

use ProstyModel;
go

create table Klienci(ID int, Klient nvarchar(20), Miasto nvarchar(30));
insert Klienci values 
	(1, 'Alfa', 'Warszawa'), 
	(2,'Beta', 'Krak�w'), 
	(3, 'Gamma', 'Warszawa'), 
	(4, 'Delta', 'Krak�w');
select * from Klienci;

create table Produkty(ID int, Produkt nvarchar(20), Grupa nvarchar(30));
insert Produkty values
	(1,'M�otek','Narz�dzia'),
	(2,'Wiertarka','Narz�dzia'),
	(3,'Pistolet','Bro�'),
	(4,'Karabin','Bro�');
select * from Produkty;

create table Sprzeda�(Klient int, Produkt int, Sprzeda� money);
insert Sprzeda� values
	(1,1,10),(1,2,20),(1,4,20),
	(2,1,10),(2,2,20),(2,4,20),
	(3,1,10),(3,2,20),(3,4,20),
	(4,1,10),(4,2,20),(4,4,20);
select * from Sprzeda�;

create table Zakup(Produkt int, Zakup money);
insert Zakup values
	(1,100),
	(2,100),
	(3,100),
	(4,100);
select * from Zakup;

