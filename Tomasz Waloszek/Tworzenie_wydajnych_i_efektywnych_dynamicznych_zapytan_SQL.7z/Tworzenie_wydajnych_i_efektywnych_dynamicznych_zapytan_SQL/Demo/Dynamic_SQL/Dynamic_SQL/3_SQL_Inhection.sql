USE AdventureWorks
GO 



-- Zapytanie obs�uguj�ce raport w naszej aplikacji


DECLARE @SQL VARCHAR(1000);
DECLARE @FirstName VARCHAR(50);

SET @FirstName = 'Ana'

SET @SQL = 'select * from Person.Person where FirstName = ''' + @FirstName + ''''

EXEC (@SQL);
GO 











-- Atak! - pr�ba pozyskania danych wszystkich naszych u�ytkownik�w

DECLARE @SQL VARCHAR(1000);
DECLARE @FirstName VARCHAR(50);

SET @FirstName = 'x'' OR 1=1 --'''

SET @SQL = 'select * from Person.Person where FirstName = ''' + @FirstName + ''''

PRINT (@SQL);
GO 











-- To mo�e zobaczmy jakie tabele ma nasza baza!!

DECLARE @SQL varchar(1000);
DECLARE @FirstName varchar(50);

SET @FirstName = ''';  select * from sys.tables --'

SET @SQL = 'select * from Person.Person where FirstName = ''' + @FirstName + ''''

PRINT (@SQL);
EXEC (@SQL);
GO 













-- Zabezpieczmy nasz� aplikacj� przed Atakiem


DECLARE @SQL NVARCHAR(1000);
DECLARE @FirstName NVARCHAR(50);
DECLARE @ParameterDefinition NVARCHAR(100)

SET @FirstName = 'x'' OR 1=1 --'''
--SET @FirstName = ''';  select * from sys.tables --'  --mo�emy zweryfikowa� r�wnie� czy jeste�my odporni na drugi atak

SET @SQL = 'select * from Person.Person where FirstName = @FirstName'

SET @ParameterDefinition =  '@FirstName VARCHAR(50)'

-- wykonanie transakt SQL

PRINT @SQL


EXECUTE sp_executesql @SQL, @ParameterDefinition, @FirstName
GO 





