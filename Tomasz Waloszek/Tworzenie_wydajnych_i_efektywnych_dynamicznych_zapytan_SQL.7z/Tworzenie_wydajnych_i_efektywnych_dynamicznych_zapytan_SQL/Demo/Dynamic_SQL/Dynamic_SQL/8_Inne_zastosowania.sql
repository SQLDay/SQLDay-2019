USE MASTER
GO 

--Backup

CREATE OR ALTER PROCEDURE dbo.backup_plan
	@differential_and_full_backup_time TIME = '00:00:00', -- Default to midnight
	@full_backup_day TINYINT = 1, -- Default to Sunday
	@backup_location NVARCHAR(MAX) = 'E:\SQLBackups\', -- Default to my backup folder
	@print_output_only BIT = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @current_time TIME = CAST(CURRENT_TIMESTAMP AS TIME);
	DECLARE @current_day TINYINT = DATEPART(DW, CURRENT_TIMESTAMP);
	DECLARE @datetime_string NVARCHAR(MAX) = FORMAT(CURRENT_TIMESTAMP , 'MMddyyyyHHmmss');
	DECLARE @sql_command NVARCHAR(MAX) = '';
	DECLARE @database_list TABLE
		(database_name NVARCHAR(MAX) NOT NULL, recovery_model_desc NVARCHAR(MAX));
	
	INSERT INTO @database_list
		(database_name, recovery_model_desc)
	SELECT
		name,
		recovery_model_desc
	FROM sys.databases
	WHERE databases.name NOT IN ('msdb', 'master', 'TempDB', 'model');
	-- Check if a full backup is to be taken now.
	IF (@current_day = @full_backup_day) AND (@current_time BETWEEN @differential_and_full_backup_time AND DATEADD(MINUTE, 10, @differential_and_full_backup_time))
	BEGIN
		SELECT @sql_command = @sql_command +
		'
		BACKUP DATABASE [' + database_name + ']
		TO DISK = ''' + @backup_location + database_name + '_' + @datetime_string + '.bak'';
		'
		FROM @database_list;
		IF @print_output_only = 1
			PRINT @sql_command;
		ELSE
			EXEC sp_executesql @sql_command;
	END
	ELSE -- Check if a differential backup is to be taken now.
	IF (@current_day <> @full_backup_day) AND (@current_time BETWEEN @differential_and_full_backup_time AND DATEADD(MINUTE, 10, @differential_and_full_backup_time))
	BEGIN
		SELECT @sql_command = @sql_command +
		'
		BACKUP DATABASE [' + database_name + ']
		TO DISK = ''' + @backup_location + database_name + '_' + @datetime_string + '.dif''
		WITH DIFFERENTIAL;
		'
		FROM @database_list;
		IF @print_output_only = 1
			PRINT @sql_command;
		ELSE
			EXEC sp_executesql @sql_command;
	END
	ELSE -- If neither full or differential, then take a transaction log backup
	BEGIN
		SELECT @sql_command = @sql_command +
		'
		BACKUP LOG [' + database_name + ']
		TO DISK = ''' + @backup_location + database_name + '_' + @datetime_string + '.trn''
		'
		FROM @database_list
		WHERE recovery_model_desc = 'FULL';
		IF @print_output_only = 1
			PRINT @sql_command;
		ELSE
			EXEC sp_executesql @sql_command;
	END
END
GO







-- Sprawdzenie naszej procedury 


EXEC dbo.backup_plan @differential_and_full_backup_time = '20:00:00', @full_backup_day = 3, @backup_location = 'D:\SQLServer2019\Backup\Demo\', @print_output_only = 1;
EXEC dbo.backup_plan @differential_and_full_backup_time = '20:00:00', @full_backup_day = 1, @backup_location = 'D:\SQLServer2019\Backup\Demo\', @print_output_only = 1;
EXEC dbo.backup_plan @differential_and_full_backup_time = '00:00:00', @full_backup_day = 1, @backup_location = 'D:\SQLServer2019\Backup\Demo\', @print_output_only = 1;
GO