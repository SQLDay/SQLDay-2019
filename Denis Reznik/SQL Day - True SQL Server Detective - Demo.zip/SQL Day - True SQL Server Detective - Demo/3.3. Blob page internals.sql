DBCC IND ('Twitter_BLOB', 'Statuses12', 1)

DBCC PAGE('Twitter_BLOB', 1, 5927632, 3) WITH TABLERESULTS -- Data Page

DBCC PAGE('Twitter_BLOB', 1, 5934583, 2) WITH TABLERESULTS -- Blob Page