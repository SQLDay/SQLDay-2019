USE AdventureWorks
GO 


-- 1. Przekazanie wynik�w do zmiennej tabelarycznej

DECLARE @SQL NVARCHAR(MAX);

DECLARE @output TABLE
(	PersonType NCHAR(2),
	Title NVARCHAR(8),
	FirstName NVARCHAR(50),
	LastName NVARCHAR(50),
	Suffix NVARCHAR(10));

DECLARE @search NVARCHAR(50) = 'Ana';
DECLARE @EmailPromotion BIT = 1;

SET @SQL = '
	SELECT
		PersonType,
		Title,
		FirstName,
		LastName,
		Suffix
	FROM Person.Person
	WHERE FirstName = ' + QUOTENAME(@search, '''');
IF @EmailPromotion = 0
	SET @SQL = @SQL + '
	AND EmailPromotion = 0';
ELSE
	SET @SQL = @SQL + '
	AND EmailPromotion <> 0';


PRINT @SQL;


INSERT INTO @output
(	PersonType,
	Title,
	FirstName,
	LastName,
	Suffix)
EXEC sp_executesql @SQL;

SELECT
	*
FROM @output;
GO













--2. Przyk�ad u�ycia paramertu OUTPUT. W przypadku u�ycie waro�� mo�e zosta� zmieniona i przekaana z powrotem do aplikacji wywo�uj�cej. 

CREATE OR ALTER  PROCEDURE dbo.Search_People
	 (@Search_Criteria NVARCHAR(1000) = NULL) -- Paramert wej�ciowy, podawany przez u�ytkownika
AS
BEGIN
	DECLARE @SQL NVARCHAR(MAX);
	DECLARE @Results_Found BIT = NULL;

	SELECT @SQL = 'SELECT * FROM Person.Person
	WHERE 1 = 1';
	IF @search_criteria IS NOT NULL
		SELECT @SQL = @SQL + '
	AND FirstName = @search_criteria;
	
	IF @@ROWCOUNT > 0
	BEGIN
		SELECT @Results_Found = 1;
	END
	';
	PRINT @SQL;


	EXEC sp_executesql @SQL, N'@search_criteria NVARCHAR(1000), @Results_Found BIT OUTPUT', @search_criteria, @Results_Found OUTPUT;  -- Je�li usuniemy klauzur� OUTPUT, zawsze otrzymamy NULL
	SELECT @Results_Found;
END
GO



EXEC dbo.Search_People 'Ana';