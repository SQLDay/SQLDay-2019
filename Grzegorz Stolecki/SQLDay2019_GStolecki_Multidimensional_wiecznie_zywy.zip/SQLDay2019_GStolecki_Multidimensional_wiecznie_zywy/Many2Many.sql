create database M2M
go

use M2M
go

create table Konta(KontoID int, KontoNumer varchar(3))
go
insert Konta values(1,'K1'), (2,'K2')
go
select * from Konta
go

create table Wlasc(WlascID int, Nazwisko varchar(20))
go
insert Wlasc values(1,'W1'), (2,'W2')
go
select * from Wlasc
go

create table FaktSalda(KontoID int, Saldo money)
go
insert FaktSalda values(1,100),(2,200)
go
select * from FaktSalda
go

create table FaktBridge(KontoID int, WlascID int)
go
insert FaktBridge values(1,1),(1,2),(2,2)
go
select * from FaktBridge
go

select * from Konta
select * from Wlasc
select * from FaktSalda
select * from FaktBridge
