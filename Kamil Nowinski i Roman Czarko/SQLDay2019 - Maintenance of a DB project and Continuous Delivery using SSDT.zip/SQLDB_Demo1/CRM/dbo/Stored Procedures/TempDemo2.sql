﻿CREATE PROCEDURE [dbo].[TempDemo2]
AS
	
	SELECT * FROM #TempTable;

RETURN 0
