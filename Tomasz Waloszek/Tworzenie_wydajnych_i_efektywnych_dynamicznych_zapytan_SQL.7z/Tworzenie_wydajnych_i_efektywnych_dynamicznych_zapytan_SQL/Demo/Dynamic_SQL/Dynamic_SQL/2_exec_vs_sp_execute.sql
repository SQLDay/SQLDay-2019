USE AdventureWorks
GO 







SET STATISTICS IO ON;
SET STATISTICS TIME ON; 
SET NOCOUNT ON;


-- U�yjmy polecenia EXEC


--Deklaracja zmiennych
DECLARE @EMPID AS SMALLINT
DECLARE @SQL AS NVARCHAR(500)

-- Ustawienie warto�ci parametru
SET @EMPID = 10

--Budujemy nasze polecenie SQL 
SET @SQL = 'SELECT * FROM HumanResources.Employee WHERE BusinessEntityID  = ' + CAST(@EMPID AS NVARCHAR(10))
-- wykonanie transakt SQL
EXECUTE(@SQL)
GO 













-- u�yjmy polecenia sp_execute

--Deklaracja zmiennych
DECLARE @EmpID AS SMALLINT
DECLARE @SQLQuery AS NVARCHAR(500)
DECLARE @ParameterDefinition AS NVARCHAR(100)

-- Ustawienie warto�ci parametru
SET @EmpID = 10

--Budujemy nasze polecenie SQL
SET @SQLQuery = 'SELECT * FROM HumanResources.Employee WHERE BusinessEntityID  = @EmpID' 

--Okre�lenie formatu parametru
SET @ParameterDefinition =  '@EmpID SMALLINT'

-- wykonanie transakt SQL
EXECUTE sp_executesql @SQLQuery, @ParameterDefinition, @EmpID
GO 













--**************************************************************
--por�wnajmy dwa sposobu uruchamiania
----------------------------------------------------
-- 1. EXEC 

--Czyszczenie plan cache
dbcc freeproccache
GO 

--w��cz plan wykonywania


DECLARE @SQL varchar(max)=''
DECLARE @param1 varchar(50)=''
DECLARE @param2 varchar(50)=''

set @param1='1'
set @param2='2'

set @SQL='select * from Person.Address where AddressID in ('+@param1+','+@param2+')'

exec(@SQL)
GO 












-- wykonajmy ponownie nasze zapytanie z inymi parametrami

DECLARE @SQL varchar(max)=''
DECLARE @param1 varchar(50)=''
DECLARE @param2 varchar(50)=''

set @param1='3'
set @param2='4'

set @SQL='select * from Person.Address where AddressID in ('+@param1+','+@param2+')'

exec(@SQL)
GO 





-- zobaczmy  plan cache

select 
	st.text,*
from sys.dm_exec_cached_plans cp
	cross apply sys.dm_exec_sql_text(cp.plan_handle) st
where 
	(st.text like '%select * from Person.Address%')
	and st.text not like '%select st.text%'







----------------------------------------------------
--2. sp_execute


--Czyszczenie plan cache
dbcc freeproccache
GO 




--sp_executesql 1

DECLARE @param1 int
DECLARE @param2 int

set @param1=1
set @param2=2

exec sp_executesql N'select * from Person.Address where AddressID in (@1,@2)'
  ,N'@1 int, @2 int',@param1, @param2

GO








-- wykonajmy ponownie nasze zapytanie

DECLARE @param1 int
DECLARE @param2 int

set @param1=3
set @param2=4

exec sp_executesql N'select * from Person.Address where AddressID in (@1,@2)'
  ,N'@1 int, @2 int',@param1, @param2

GO







-- zobaczmy jak teraz wygl�da cache plan

select 
	st.text,*
from sys.dm_exec_cached_plans cp
	cross apply sys.dm_exec_sql_text(cp.plan_handle) st
where 
	(st.text like '%select * from Person.Address%')
	and st.text not like '%select st.text%'
GO 







--Zobaczmy jak by wygl�da� kod dla naszego wcze�niejszego przyk�adu


-- Using sp_executesql, it would look like this:
DECLARE @SQL NVARCHAR(MAX) = ''; -- This will hold the final SQL to execute
DECLARE @First_Name NVARCHAR(50) = 'Edward'; -- First name as entered in search box
DECLARE @Phone_Number_Type NVARCHAR(10) = 'Cell'; -- Phone number type as entered in drop-down.  Optional.
SELECT @SQL = 
'
SELECT
	P.FirstName,
	P.LastName,
	PPh.PhoneNumber,
	PNT.Name
FROM Person.Person AS P
INNER JOIN Person.PersonPhone AS PPh
	ON P.BusinessEntityID = PPh.BusinessEntityID
INNER JOIN Person.PhoneNumberType AS PNT
	ON PPh.PhoneNumberTypeID = PNT.PhoneNumberTypeID
WHERE P.FirstName = ''' + @First_Name + '''
';

IF @Phone_Number_Type IS NOT NULL -- Only check phone # type if value is supplied!
BEGIN
	SELECT @SQL = @SQL +
	'
	AND PNT.Name = ''' + @Phone_Number_Type + '''
	';
END

PRINT @SQL;
EXEC sp_executesql @SQL, N'@first_name NVARCHAR(50), @phone_number_type NVARCHAR(10)', @First_Name, @Phone_Number_Type;

-- Aby poprawi� czytelno�� list� parametr�w r�wnie� mo�emy przechowywa� w zmiennej skalarnej
DECLARE @Parameter_List NVARCHAR(MAX) = N'@first_name NVARCHAR(50), @phone_number_type NVARCHAR(10)';


EXEC sp_executesql @SQL, @Parameter_List, @First_Name, @Phone_Number_Type;
GO










--**************************************************************
-- Czy zawsze sp_execute jest lepszy od EXEC??
-- Czyszczenie plan cache
dbcc freeproccache
GO 

-- w��czmy statystyki 
SET statistics IO ON;

GO 

--Czy zawsze sp_execute b�dzie lepsze?

-- Wykonajmy sobie zapytanie w kliku wariantach

DECLARE @ExecStr NVARCHAR(4000);
SELECT @ExecStr = 'SELECT * FROM Person.Person WHERE FirstName LIKE @FirstName';
EXEC sp_executesql @ExecStr, N'@FirstName varchar(15)', 'Jodan';
GO


DECLARE @ExecStr NVARCHAR(4000);
SELECT @ExecStr = 'SELECT * FROM Person.Person WHERE FirstName LIKE @FirstName';
EXEC sp_executesql @ExecStr, N'@FirstName varchar(15)', 'Ana';
GO


DECLARE @ExecStr NVARCHAR(4000);
SELECT @ExecStr = 'SELECT * FROM Person.Person WHERE FirstName LIKE @FirstName';
EXEC sp_executesql @ExecStr, N'@FirstName varchar(15)', 'Jennifer';
GO




SELECT st.text, qs.EXECUTION_COUNT ,cp.* 
FROM sys.dm_exec_query_stats AS qs 
	CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS st
	CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS cp
WHERE st.text like '%FROM Person.Person%'
GO




DECLARE @ExecStr NVARCHAR(4000);
SELECT @ExecStr = 'SELECT * FROM Person.Person WHERE FirstName LIKE @FirstName OPTION(RECOMPILE)';
EXEC sp_executesql @ExecStr, N'@FirstName varchar(15)', 'Jennifer';
GO



SELECT st.text, qs.EXECUTION_COUNT ,cp.* 
FROM sys.dm_exec_query_stats AS qs 
	CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS st
	CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS cp
WHERE st.text like '%FROM Person.Person%'
GO


