USE TameTheBeast;
GO

CREATE TABLE dbo.LoginAudit (
	[Id] int IDENTITY NOT NULL,
	[LoginName] nvarchar(128) NOT NULL,
	[DatabaseName] nvarchar(128) NOT NULL,
	[ApplicationName] nvarchar(128) NULL,
	[HostName] nvarchar(128) NULL,
	[HostIP] varchar(48) NULL,	
	[FirstLoginDatetime] datetime NOT NULL,
	[LastLoginDateTime] datetime NOT NULL,
	[Count] int NOT NULL,
	CONSTRAINT pk_LoginAudit PRIMARY KEY CLUSTERED ([ID]),
	INDEX ix_LoginAudit NONCLUSTERED ([LoginName], [DatabaseName], [ApplicationName], [HostName], [HostIP])
);
GO

CREATE TRIGGER LoginAuditTrigger  
ON ALL SERVER WITH EXECUTE AS 'SA'
FOR LOGON  
AS  
BEGIN
	IF OBJECT_ID (N'TameTheBeast.dbo.LoginAudit', N'U') IS NOT NULL
	BEGIN

		UPDATE TameTheBeast.dbo.LoginAudit
		SET [Count] = [Count] + 1,
		    LastLoginDateTime = GETUTCDATE()
		FROM sys.dm_exec_connections c
		JOIN sys.dm_exec_sessions s 
			 ON c.session_id = s.session_id
		JOIN TameTheBeast.dbo.LoginAudit la 
			 ON la.LoginName = s.original_login_name 
			AND la.DatabaseName = DB_NAME(s.database_id) 
			AND la.ApplicationName = s.program_name 
			AND la.HostName = s.host_name 
			AND la.HostIP = c.client_net_address
		WHERE s.session_id = @@spid

		IF @@rowcount = 0
		BEGIN
			INSERT INTO TameTheBeast.dbo.LoginAudit (LoginName, DatabaseName, HostName, HostIP, ApplicationName, FirstLoginDatetime, LastLoginDatetime, [Count])
			SELECT s.original_login_name, DB_NAME(s.database_id) AS database_name, s.host_name, c.client_net_address, s.program_name, GETUTCDATE(), GETUTCDATE(), 1 
			FROM sys.dm_exec_connections c
			JOIN sys.dm_exec_sessions s ON c.session_id = s.session_id
			WHERE s.session_id = @@spid
		END
	END  
END;  
GO

/*

SELECT * FROM TameTheBeast.dbo.LoginAudit ORDER BY Id;

--*/


/* CLEANUP
DROP TRIGGER LoginAuditTrigger ON ALL SERVER;
GO

DROP TABLE dbo.LoginAudit;
GO
--*/