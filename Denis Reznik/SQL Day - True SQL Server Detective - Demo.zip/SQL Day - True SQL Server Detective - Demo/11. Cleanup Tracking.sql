USE Test
GO

SELECT * FROM [dbo].[CT_CPU_TRACKING]
ORDER BY CurrentDate DESC

-- Start ~ 9:55
-- Stop Workload - 10:24

-- 16:35 start workload
-- 2019-05-14 16:42:00.953	3700
-- 2019-05-14 16:43:00.960	46500
-- 2019-05-14 17:10:01.003	1358042
-- 2019-05-14 17:11:01.027	0

-- autocleanup - on - 11:46
-- 2019-05-15 12:11:00.783	38904
-- 13:23 - server start
