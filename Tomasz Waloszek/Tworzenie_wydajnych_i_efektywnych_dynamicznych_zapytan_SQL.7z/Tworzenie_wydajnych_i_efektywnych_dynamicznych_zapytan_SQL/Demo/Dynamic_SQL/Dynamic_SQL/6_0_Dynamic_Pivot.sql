use AdventureWorks
GO 


SELECT
	*
FROM
(	SELECT
		p.Name AS product_name,
		p.Color AS product_color,
		sd.OrderQty AS product_qty
	FROM Production.Product AS p
	INNER JOIN [Sales].[SalesOrderDetail] as sd
	ON p.ProductID = sd.ProductID
	

) PRODUCT_DATA
PIVOT
(	SUM(product_qty)
	FOR product_color IN ([Black], [Blue], [Grey], [Multi], [Red], [Silver], [Silver/Black], [White], [Yellow]  )
) PIVOT_DATA
order by product_name DESC







-- Dynamiczny SQL daje nam mo�liwo�� "zautomatyzowania" naszego pivot, przez dostarczenie parametru z list� kolor�w


DECLARE @Color_List TABLE
	(Color_Name VARCHAR(25)	);

INSERT INTO @Color_List
	(Color_Name)
VALUES ('Black'), ('Grey'), ('Silver/Black'), ('White');

DECLARE @Sql_Command NVARCHAR(MAX);
SET @Sql_Command = '
SELECT
	*
FROM
(	SELECT
		p.Name AS product_name,
		p.Color AS product_color,
		sd.OrderQty AS product_qty
	FROM Production.Product AS p
	INNER JOIN [Sales].[SalesOrderDetail] as sd
	ON p.ProductID = sd.ProductID
) PRODUCT_DATA
PIVOT
(	SUM(product_qty)
	FOR product_color IN (';

SELECT
	@Sql_Command = @Sql_Command + '[' + Color_Name + '], '
FROM @Color_List;

SELECT @Sql_Command = SUBSTRING(@Sql_Command, 1, LEN(@Sql_Command) - 1);

SELECT @Sql_Command = @Sql_Command + '	)
) PIVOT_DATA
order by product_name DESC
'

PRINT @Sql_Command;
EXEC sp_executesql @Sql_Command;
GO












--wygenerujmy list� kolor�w na podstawie danych z tableli Production.Product


DECLARE @Color_List TABLE
	(Color_Name VARCHAR(25)	);

INSERT INTO @Color_List
	(Color_Name)
SELECT DISTINCT
	Product.Color
FROM Production.Product
WHERE Product.Color IS NOT NULL;

DECLARE @Sql_Command NVARCHAR(MAX);
SET @Sql_Command = '
SELECT
	*
FROM
(	SELECT
		p.Name AS product_name,
		p.Color AS product_color,
		sd.OrderQty AS product_qty
	FROM Production.Product AS p
	INNER JOIN [Sales].[SalesOrderDetail] as sd
	ON p.ProductID = sd.ProductID
) PRODUCT_DATA
PIVOT
(	SUM(product_qty)
	FOR product_color IN (';

SELECT
	@Sql_Command = @Sql_Command + '[' + Color_Name + '], '
FROM @Color_List;

SELECT @Sql_Command = SUBSTRING(@Sql_Command, 1, LEN(@Sql_Command) - 1);

SELECT @Sql_Command = @Sql_Command + '	)
) PIVOT_DATA
order by product_name DESC
'

PRINT @Sql_Command;
EXEC sp_executesql @Sql_Command;
GO









-- Zr�bmy test i zmodyfikujmy nasze dane
UPDATE Production.Product
	SET Product.Color = 'Lime'
WHERE Product.ProductID = 852; 
UPDATE Production.Product
	SET Product.Color = 'Green'
WHERE Product.ProductID = 853;



--Sprawd�my nasze wyniki

DECLARE @Color_List TABLE
	(Color_Name VARCHAR(25)	);

INSERT INTO @Color_List
	(Color_Name)
SELECT DISTINCT
	Product.Color
FROM Production.Product
WHERE Product.Color IS NOT NULL;

DECLARE @Sql_Command NVARCHAR(MAX);
SET @Sql_Command = '
SELECT
	*
FROM
(	SELECT
		p.Name AS product_name,
		p.Color AS product_color,
		sd.OrderQty AS product_qty
	FROM Production.Product AS p
	INNER JOIN [Sales].[SalesOrderDetail] as sd
	ON p.ProductID = sd.ProductID
) PRODUCT_DATA
PIVOT
(	SUM(product_qty)
	FOR product_color IN (';

SELECT
	@Sql_Command = @Sql_Command + '[' + Color_Name + '], '
FROM @Color_List;

SELECT @Sql_Command = SUBSTRING(@Sql_Command, 1, LEN(@Sql_Command) - 1);

SELECT @Sql_Command = @Sql_Command + '	)
) PIVOT_DATA
order by product_name DESC
'

PRINT @Sql_Command;
EXEC sp_executesql @Sql_Command;
GO









--wycofajmy zmiany 
UPDATE Production.Product
	SET Product.Color = 'Black'
WHERE Product.ProductID IN ( 852, 853); 
