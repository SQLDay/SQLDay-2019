--5 CompletePredictiveSolution
--Write a complete predictive solution building some models, training and invoking a predictive function.  

USE PredictiveMaintenance;
GO

SELECT * FROM dbo.vw_ProductFailureCountAge;
--Model training: dataset based on 70% of data
--Model testing: dataset based on 30% data

-- Create a table to store the calculated models 
DROP TABLE IF EXISTS dbo.Failure_data_models;
GO

CREATE TABLE [dbo].Failure_data_models
(
	 [model_name] VARCHAR(100) NOT NULL
	,[model] VARBINARY(MAX) NOT NULL
	,CreationDate SMALLDATETIME NOT NULL DEFAULT(GETDATE())
	,Accuracy INT NULL
);
GO

/********************************************************************************************************************
Create a model with Random Forest algorithm
Random forest builds multiple decision trees and merges them together to get a more accurate and stable prediction. 
The stored procedure produces two ouput: the trained model and the accuracy. The test dataset is used to calculate
accuracy for this model. 
*********************************************************************************************************************/
DROP PROCEDURE IF EXISTS dbo.usp_forest_model;
GO

CREATE OR ALTER PROCEDURE dbo.usp_forest_model  (
	 @trained_model VARBINARY(MAX) OUTPUT
	,@accuracy FLOAT OUTPUT
	)
AS
BEGIN
    EXEC sp_execute_external_script
     @language = N'R'
    ,@script = N'
		library(RevoScaleR)
		library(caTools)
        library(MLmetrics)
		ds_fail <- InputDataSet
		set.seed(2910) 
		Split <- .70
		sample = sample.split(ds_fail$TotFailure, SplitRatio = Split)
		train_ds_fail <- subset(ds_fail, sample == TRUE)
		test_ds_fail  <- subset(ds_fail, sample == FALSE)
			
		y_train <- train_ds_fail$TotFailure
		y_test <- test_ds_fail$TotFailure
        train_var <- rxGetVarNames(ds_fail)
        formula <- as.formula(paste("TotFailure ~", paste(train_var, collapse = "+")))
		
		forest_model <- rxDForest(formula = formula, data = train_ds_fail, nTree = 40, minSplit = 10, minBucket = 5, cp = 0.00005, seed = 5)
		trained_model <- as.raw(serialize(forest_model, connection=NULL))
		
		#calculating accuracy
        y_predicted<- rxPredict(forest_model,test_ds_fail)
		predict_forest <-data.frame(actual=y_test,pred=y_predicted)
		accu <- LogLoss(y_pred = predict_forest$TotFailure, y_true =predict_forest$actual)
		accuracy <- accu'

	,@input_data_1 = N'SELECT * FROM dbo.vw_ProductFailureCountAge'
	,@params = N'@trained_model VARBINARY(MAX) OUTPUT, @accuracy FLOAT OUTPUT'
    ,@trained_model = @trained_model OUTPUT
	,@accuracy = @accuracy OUTPUT;
END;
GO

--recall the stored procedure and insert the calculated model into a table. 
DECLARE @model VARBINARY(MAX);
DECLARE @accur FLOAT;
EXEC dbo.usp_forest_model @model OUTPUT, @accur OUTPUT;
INSERT INTO [dbo].[Failure_data_models] (model_name, model, accuracy) VALUES('Random_forest_model_' + CAST(ROUND(RAND(),3)*1000 AS nchar(3)), @model, @accur);
GO

SELECT * FROM [dbo].[Failure_data_models];

/*************************************************************************************************************************************************************************
Same as above. This time using the Gradient boosting algorithm. 
From Wikipedia: "Gradient boosting is a machine learning technique for regression and classification problems, 
which produces a prediction model in the form of an ensemble of weak prediction models, typically decision trees. 
It builds the model in a stage-wise fashion like other boosting methods do, and it generalizes them by allowing optimization 
of an arbitrary differentiable loss function."
**************************************************************************************************************************************************************************/
DROP PROCEDURE IF EXISTS dbo.usp_btree_model;
GO       
	         
CREATE OR ALTER PROCEDURE dbo.usp_btree_model(
	 @trained_model VARBINARY(MAX) OUTPUT
	,@accuracy FLOAT OUTPUT
	)
AS
BEGIN
    EXEC sp_execute_external_script
     @language = N'R'
    ,@script = N'
		library(RevoScaleR)
		library(caTools)
        library(MLmetrics)
		ds_fail <- InputDataSet
		set.seed(2910) 
		Split <- .70
		sample = sample.split(ds_fail$TotFailure, SplitRatio = Split)
		train_ds_fail <- subset(ds_fail, sample == TRUE)
		test_ds_fail  <- subset(ds_fail, sample == FALSE)
		y_train <- train_ds_fail$TotFailure
		y_test <- test_ds_fail$TotFailure
        train_var <- rxGetVarNames(ds_fail)
        formula <- as.formula(paste("TotFailure ~", paste(train_var, collapse = "+")))

        btree_model <- rxBTrees(formula = formula,data = train_ds_fail,learningRate = 0.05,minSplit = 10,minBucket = 5,cp = 0.0005
			,nTree = 40,seed = 5,lossFunction = "gaussian")
		trained_model <- as.raw(serialize(btree_model, connection=NULL))

		#calculating accuracy
        y_predicted<- rxPredict(btree_model,test_ds_fail)
		predict_btree <-data.frame(actual=y_test,pred=y_predicted)
		accu <- LogLoss(y_pred = predict_btree$TotFailure, y_true =predict_btree$actual)
		accuracy <- accu'

	,@input_data_1 = N'SELECT * FROM dbo.vw_ProductFailureCountAge'
	,@params = N'@trained_model VARBINARY(MAX) OUTPUT, @accuracy FLOAT OUTPUT'
    ,@trained_model = @trained_model OUTPUT
	,@accuracy = @accuracy OUTPUT;
END;
GO

DECLARE @model VARBINARY(MAX);
DECLARE @accur FLOAT;
EXEC dbo.usp_btree_model @model OUTPUT, @accur OUTPUT;
INSERT INTO [dbo].[Failure_data_models] (model_name, model, accuracy) VALUES('Gradient_boosting_model_' + CAST(ROUND(RAND(),3)*1000 AS nchar(3)), @model, @accur);
GO


SELECT * FROM [dbo].[Failure_data_models];
GO
--Performing Predictions from the trained models
--the stored procedure accepts the model name and a custom sql query as input
CREATE OR ALTER  PROCEDURE [dbo].[usp_FailurePrediction] 
(
		 @model VARCHAR(30)
		,@query NVARCHAR(MAX)
)
AS
BEGIN
	DECLARE @nar_model VARBINARY(MAX) = (SELECT model FROM [dbo].[Failure_data_models] WHERE model_name = @model);

	EXEC sp_execute_external_script
		 @language = N'R'
		,@script = N'
				test_data <- InputDataSet
				model <- unserialize(nar_model)			

				prediction <- rxPredict(model,data = test_data, overwrite = TRUE, type="response",extraVarsToWrite = NULL)
				Prediction_New <- rxImport(inData = prediction, stringsAsFactors = T, outFile = NULL)

				OutputDataSet <- data.frame(Prediction_New,test_data$AgeMonth)
				'
		,@input_data_1 =  @query
		,@params = N'@nar_model VARBINARY(MAX)'
		,@nar_model = @nar_model
	WITH RESULT SETS((		 
		 Prediction float
		 ,AgeMonth INT
	))
END;


-- Example of running predictions agains selected model with a custom query
EXEC [dbo].[usp_FailurePrediction]  
	 @model = N'Random_forest_model_445'
	,@query = N'SELECT 23 AS AgeMonth, 0 AS TotFailure'


EXEC [dbo].[usp_FailurePrediction]  
	 @model = N'Gradient_boosting_model_608'
	,@query = N'SELECT 23 AS AgeMonth, 0 AS TotFailure'
GO
/*******************************************************************************************************************
As last trained model, reuse the simple regression linear model, this time splitting among train and test datasets.
*********************************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.usp_linear_trained_model  (
	 @trained_model VARBINARY(MAX) OUTPUT 
	,@accuracy FLOAT OUTPUT
	)
AS
BEGIN
    EXEC sp_execute_external_script
     @language = N'R'
    ,@script = N'
		library(RevoScaleR)
		library(caTools)
        library(MLmetrics)
		ds_fail <- InputDataSet
		set.seed(2910) 
		Split <- .70
		sample = sample.split(ds_fail$TotFailure, SplitRatio = Split)
		train_ds_fail <- subset(ds_fail, sample == TRUE)
		test_ds_fail  <- subset(ds_fail, sample == FALSE)
			
		y_train <- train_ds_fail$TotFailure
		y_test <- test_ds_fail$TotFailure
        train_var <- rxGetVarNames(ds_fail)
        
		formula <- as.formula(paste("TotFailure ~", paste(train_var, collapse = "+")))
		linear_model <- rxLinModel(formula = formula, data = train_ds_fail)
		trained_model <- as.raw(serialize(linear_model, connection=NULL))
		
		#calculating accuracy
        y_predicted<- rxPredict(linear_model,test_ds_fail)
		predict_linear <-data.frame(actual=y_test,pred=y_predicted)
		accu <- LogLoss(y_pred = predict_linear$TotFailure, y_true = predict_linear$actual)
		accuracy <- accu
		months <- InputDataSet$AgeMonth
		'

	,@input_data_1 = N'SELECT * FROM dbo.vw_ProductFailureCountAge'
	,@params = N'@trained_model VARBINARY(MAX) OUTPUT, @accuracy FLOAT OUTPUT'
    ,@trained_model = @trained_model OUTPUT
	,@accuracy = @accuracy OUTPUT;
END;
GO

--recall the stored procedure and insert the calculated model into a table. 
DECLARE @model VARBINARY(MAX);
DECLARE @accur FLOAT;
EXEC dbo.usp_forest_model @model OUTPUT, @accur OUTPUT;
INSERT INTO [dbo].[Failure_data_models] (model_name, model, accuracy) VALUES('linear_model_' + CAST(ROUND(RAND(),3)*1000 AS nchar(3)), @model, @accur);
GO


SELECT * FROM [dbo].[Failure_data_models];

EXEC [dbo].[usp_FailurePrediction]  
	 @model = N'linear_model_469'
	,@query = N'SELECT AgeMonth, TotFailure FROM dbo.AgeTestData'

EXEC [dbo].[usp_FailurePrediction]  
	 @model = N'Random_forest_model_445'
	,@query = N'SELECT AgeMonth, TotFailure FROM dbo.AgeTestData'

EXEC [dbo].[usp_FailurePrediction]  
	 @model = N'Gradient_boosting_model_690'
	,@query = N'SELECT AgeMonth, TotFailure FROM dbo.AgeTestData'


--Plot the model using rxLinePlot function.
--Parameters for plot type: "smooth" = loess fit, "r" =	regression line

EXECUTE sp_execute_external_script
 @language = N'R'
 , @script = N'
     imageDir <- ''C:\\temp\\Rplot'';
     image_filename = tempfile(pattern = "rxLinePlot_", tmpdir = imageDir, fileext = ".jpg")
     print(image_filename);
     jpeg(filename=image_filename,  width=600, height = 800);
     print(rxLinePlot(TotFailure~AgeMonth, data=InputDataSet, type = "smooth"));
     dev.off();
     OutputDataSet <- data.frame(data=readBin(file(image_filename, "rb"), what=raw(), n=1e6));
     '
  , @input_data_1 = N'SELECT AgeMonth, TotFailure FROM dbo.vw_ProductFailureCountAge'
  WITH RESULT SETS ((plot varbinary(max)));
 
 --Wrap all the output tables and plots into Reporting Services. Report 2 CompletePredictiveSolution


/********************************************************************************************************************************
Calculate the regression model for every component.
Encapsulate into an sp that accepts the failure as parameter.
Store the calculated model into a table for reusing
*********************************************************************************************************************************/
IF EXISTS (SELECT * FROM sys.procedures WHERE name = N'usp_linear_model_single_failure' AND schema_id = 1)
DROP PROCEDURE dbo.usp_linear_model_single_failure;
GO

CREATE OR ALTER PROCEDURE dbo.usp_linear_model_single_failure 
	@Failure nvarchar(50)
AS 
BEGIN
	DECLARE @input_dst nvarchar(1000); 
	SET @input_dst = N'SELECT AgeMonth, TotFailure FROM dbo.vw_ProductFailureCause WHERE FailureDescription = ''' + @Failure + '''';
	EXEC sys.sp_execute_external_script
	@language = N'R'
	, @script = N'
		form <- TotFailure ~ AgeMonth
		FailLinMod <- rxLinMod(form, data = sqlData)
		tmodel <- data.frame(payload = as.raw(serialize(FailLinMod, connection = NULL)));
		'
	, @input_data_1 = @input_dst
	, @input_data_1_name = N'sqlData'
	, @output_data_1_name = N'tmodel'
	WITH RESULT SETS((model varbinary(max)));
END 
GO

--Create a table to store the output every time the model is processed
IF EXISTS (SELECT * FROM sys.tables WHERE name = N'FailureType_model' AND schema_id = 1)
DROP TABLE dbo.FailureType_model;

CREATE TABLE dbo.FailureType_model(
	id INT IDENTITY(1,1) PRIMARY KEY, 
    failure_type nvarchar(50),
	execution_time datetime2 DEFAULT(CURRENT_TIMESTAMP),
    model_output varbinary(max)
	);

--test the stored procedure and populate the model table
DECLARE @f_type nvarchar(50) = N'Gear'
INSERT INTO dbo.FailureType_model(model_output)
EXEC dbo.usp_linear_model_single_failure @f_type ;

UPDATE dbo.FailureType_model SET failure_type = @f_type
WHERE id = (SELECT IDENT_CURRENT('dbo.FailureType_model'));

--What there is in the table?
SELECT id, failure_type,model_output FROM dbo.FailureType_model;

--prediction for frames
DECLARE @f_model varbinary(max) = (SELECT model_output FROM dbo.FailureType_model WHERE failure_type = 'Frame');
EXEC sp_execute_external_script
	@language = N'R'
	, @script = N'
			current_model <- unserialize(as.raw(f_model));
			pass <- data.frame(T_AgeData);
			predicted.fail <- rxPredict(current_model,pass);
			str(predicted.fail);
			OutputDataSet <- cbind(pass, ceiling(predicted.fail));
			'
	, @input_data_1 = N'SELECT AgeMonth FROM [dbo].[AgeTestData]'
	, @input_data_1_name = N'T_AgeData'
	, @params = N'@f_model varbinary(max)'
	, @f_model = @f_model
WITH RESULT SETS (([AgeMonth] INT, [Predicted_Failure] INT));

--prediction for brakes
DECLARE @b_model varbinary(max) = (SELECT model_output FROM dbo.FailureType_model WHERE failure_type = 'Brake');
EXEC sp_execute_external_script
	@language = N'R'
	, @script = N'
			current_model <- unserialize(as.raw(b_model));
			pass <- data.frame(T_AgeData);
			predicted.fail <- rxPredict(current_model,pass);
			str(predicted.fail);
			OutputDataSet <- cbind(pass, ceiling(predicted.fail));
			'
	, @input_data_1 = N'SELECT AgeMonth FROM [dbo].[AgeTestData]'
	, @input_data_1_name = N'T_AgeData'
	, @params = N'@b_model varbinary(max)'
	, @b_model = @b_model
WITH RESULT SETS (([AgeMonth] INT, [Predicted_Failure] INT));


/****************************************************************************************************************************
Bind together all predictions for every component
*****************************************************************************************************************************/
IF EXISTS (SELECT * FROM sys.tables WHERE name = N'FailurePredictionComponent' AND schema_id = 1)
DROP TABLE dbo.FailurePredictionComponent;

CREATE TABLE dbo.FailurePredictionComponent(
    AgeMonth int,
	PredictedFailure int,
	Component nvarchar(50), 
	DateCalculated datetime2 DEFAULT GETDATE()
	);
GO

--embed all calculations in a sp that gets the age as input parameter 
CREATE OR ALTER PROCEDURE dbo.usp_FailurePredictionAllComponent
	@Age nvarchar(10)
AS 
BEGIN 

	TRUNCATE TABLE dbo.FailurePredictionComponent;

	DECLARE @InputDataScript nvarchar(max)
	SET @InputDataScript = N'SELECT ' + @Age + ' AS AgeMonth';

	--Brake
	DECLARE @b_model varbinary(max) = (SELECT model_output FROM dbo.FailureType_model WHERE failure_type = 'Brake');
	INSERT INTO dbo.FailurePredictionComponent(AgeMonth, PredictedFailure, Component)
	EXEC sp_execute_external_script
		@language = N'R'
		, @script = N'
				current_model <- unserialize(as.raw(b_model));
				pass <- data.frame(T_AgeData);
				predicted.fail <- rxPredict(current_model,pass);
				str(predicted.fail);
				OutputDataSet <- cbind(pass, ceiling(predicted.fail),"Brake");
				'
		, @input_data_1 = @InputDataScript
		, @input_data_1_name = N'T_AgeData'
		, @params = N'@b_model varbinary(max)'
		, @b_model = @b_model

	--Frame
	DECLARE @f_model varbinary(max) = (SELECT model_output FROM dbo.FailureType_model WHERE failure_type = 'Frame');
	INSERT INTO dbo.FailurePredictionComponent(AgeMonth, PredictedFailure, Component)
	EXEC sp_execute_external_script
		@language = N'R'
		, @script = N'
				current_model <- unserialize(as.raw(f_model));
				pass <- data.frame(T_AgeData);
				predicted.fail <- rxPredict(current_model,pass);
				str(predicted.fail);
				OutputDataSet <- cbind(pass, ceiling(predicted.fail),"Frame");
				'
		, @input_data_1 = @InputDataScript
		, @input_data_1_name = N'T_AgeData'
		, @params = N'@f_model varbinary(max)'
		, @f_model = @f_model


	--Pedal
	DECLARE @p_model varbinary(max) = (SELECT model_output FROM dbo.FailureType_model WHERE failure_type = 'Pedal');
	INSERT INTO dbo.FailurePredictionComponent(AgeMonth, PredictedFailure, Component)
	EXEC sp_execute_external_script
		@language = N'R'
		, @script = N'
				current_model <- unserialize(as.raw(p_model));
				pass <- data.frame(T_AgeData);
				predicted.fail <- rxPredict(current_model,pass);
				str(predicted.fail);
				OutputDataSet <- cbind(pass, ceiling(predicted.fail),"Pedal");
				'
		, @input_data_1 = @InputDataScript
		, @input_data_1_name = N'T_AgeData'
		, @params = N'@p_model varbinary(max)'
		, @p_model = @p_model

	--Chain
	DECLARE @c_model varbinary(max) = (SELECT model_output FROM dbo.FailureType_model WHERE failure_type = 'Chain');
	INSERT INTO dbo.FailurePredictionComponent(AgeMonth, PredictedFailure, Component)
	EXEC sp_execute_external_script
		@language = N'R'
		, @script = N'
				current_model <- unserialize(as.raw(c_model));
				pass <- data.frame(T_AgeData);
				predicted.fail <- rxPredict(current_model,pass);
				str(predicted.fail);
				OutputDataSet <- cbind(pass, ceiling(predicted.fail),"Chain");
				'
		, @input_data_1 = @InputDataScript
		, @input_data_1_name = N'T_AgeData'
		, @params = N'@c_model varbinary(max)'
		, @c_model = @c_model

	--Wheel Rim
	DECLARE @wr_model varbinary(max) = (SELECT model_output FROM dbo.FailureType_model WHERE failure_type = 'Wheel rim');
	INSERT INTO dbo.FailurePredictionComponent(AgeMonth, PredictedFailure, Component)
	EXEC sp_execute_external_script
		@language = N'R'
		, @script = N'
				current_model <- unserialize(as.raw(wr_model));
				pass <- data.frame(T_AgeData);
				predicted.fail <- rxPredict(current_model,pass);
				str(predicted.fail);
				OutputDataSet <- cbind(pass, ceiling(predicted.fail),"WheelRim");
				'
		, @input_data_1 = @InputDataScript
		, @input_data_1_name = N'T_AgeData'
		, @params = N'@wr_model varbinary(max)'
		, @wr_model = @wr_model

	--Gear
	DECLARE @g_model varbinary(max) = (SELECT model_output FROM dbo.FailureType_model WHERE failure_type = 'Gear');
	INSERT INTO dbo.FailurePredictionComponent(AgeMonth, PredictedFailure, Component)
	EXEC sp_execute_external_script
		@language = N'R'
		, @script = N'
				current_model <- unserialize(as.raw(g_model));
				pass <- data.frame(T_AgeData);
				predicted.fail <- rxPredict(current_model,pass);
				str(predicted.fail);
				OutputDataSet <- cbind(pass, ceiling(predicted.fail),"Gear");
				'
		, @input_data_1 = @InputDataScript
		, @input_data_1_name = N'T_AgeData'
		, @params = N'@g_model varbinary(max)'
		, @g_model = @g_model

	
	SELECT AgeMonth, PredictedFailure, Component
	FROM dbo.FailurePredictionComponent

	/*
	--pivot the output and pass to the sp	
	SELECT AgeMonth, [Brake],[Frame],[Pedal],[Chain],[WheelRim],[Gear]
	FROM 
	(
	SELECT AgeMonth, PredictedFailure, Component
	FROM dbo.FailurePredictionComponent) src
		PIVOT (
			MAX(PredictedFailure) 
			FOR Component IN ([Brake],[Frame],[Pedal],[Chain],[WheelRim],[Gear])
		) pvt
	*/
END

--Test the sp
DECLARE @AgeInput nvarchar(10); 
SET @AgeInput = N'24';
EXEC dbo.usp_FailurePredictionAllComponent @AgeInput;

--show the output in Reporting Services. Report 3 PredictionAllComponent
