USE AdventureWorksDW2017
GO 

--W��cz plan wykonania

--Zapytanie w raporcie

DECLARE @Kategotia_promocji varchar(50);
DECLARE @Typ_promocji varchar(50);
DECLARE @Plec varchar(50);
DECLARE @Rodzaj varchar(50);
DECLARE @Rok varchar(50);
DECLARE @Miesiac varchar(50);

; WITH fakty AS ( 
	SELECT  
		Prom.EnglishPromotionCategory AS Kategotia_promocji
		,Prom.EnglishPromotionType AS Typ_promocji
		,CONCAT(C.FirstName,' ', C.LastName) AS Klient
		,C.Gender AS Plec
		,YEAR(F.OrderDate) AS Rok 
		,MONTH(F.OrderDate) AS Miesiac
		,F.ProductStandardCost AS Koszt_produktu
		,F.SalesAmount AS Wartosc_sprzedazy
		,'Internet' AS Rodzaj
	FROM 
	[dbo].[FactInternetSales] AS F
	LEFT JOIN DimCustomer AS C
		ON C.CustomerKey = F.CustomerKey
	LEFT JOIN DimPromotion AS Prom
		ON F.PromotionKey = Prom.PromotionKey

	UNION ALL

		SELECT  
		Prom.EnglishPromotionCategory AS Kategotia_promocji
		,Prom.EnglishPromotionType AS Typ_promocji
		,'N/D' AS Klient
		,'N/D' AS Plec
		,YEAR(F.OrderDate) AS Rok 
		,MONTH(F.OrderDate) AS Miesiac
		,F.ProductStandardCost AS Koszt_produktu
		,F.SalesAmount AS Wartosc_sprzedazy
		,'Po�rednia' AS Rodzaj
	FROM 
	[dbo].[FactResellerSales] AS F

	LEFT JOIN DimPromotion AS Prom
		ON F.PromotionKey = Prom.PromotionKey

)


SELECT 
Kategotia_promocji
,Typ_promocji
,Klient
,Plec
,Rok 
,Miesiac
,Rodzaj
, SUM(Koszt_produktu) AS Koszt_produktu
, SUM(Wartosc_sprzedazy) AS Wartosc_sprzedazy

FROM fakty
GROUP BY 
	 Kategotia_promocji
	,Typ_promocji
	,Klient
	,Plec
	,Rok 
	,Miesiac
	,Rodzaj

GO 










--Zoptymalizujmy nasze zapytanie jako �r�d�o danych do raportu

-- 1. Zmieniamy skrypt na procedur�, przyjmuj�c� podawane parametry
-- 2. Przepiszmy zapytanie na dynamiczny kod SQL



CREATE OR ALTER PROCEDURE dbo.usp_Raport_sprzedazy
				@Rodzaj NVARCHAR(50)= NULL,
				@Rok SMALLINT= NULL,
				@Miesiac TINYINT= NULL,
				@Kategotia_promocji NVARCHAR(50)= NULL,
				@Typ_promocji NVARCHAR(50)= NULL,
				@Plec NVARCHAR(1)= NULL,
				@Klient NVARCHAR(50)= NULL,
				@Debug BIT = 1
----------
AS
    Set NoCount ON

	
	--Definicja Parametr�w
	Declare @ParamDefinition AS NVARCHAR(2000) 
	Set @ParamDefinition =      
				'@Rok SMALLINT,
				 @Miesiac TINYINT,
				 @Kategotia_promocji NVARCHAR(50),
				 @Typ_promocji NVARCHAR(50),
				 @Plec NVARCHAR(1),
				 @Klient NVARCHAR(50)
				 '

		--Wyznaczenie kodu SQL
		DECLARE @SQL NVARCHAR(MAX)
		SET @SQL = '
		; WITH fakty AS ( '

		IF @Rodzaj = 'Internet' OR @Rodzaj IS NULL
		SET @SQL = @SQL + 
			'SELECT  
				Prom.EnglishPromotionCategory AS Kategotia_promocji
				,Prom.EnglishPromotionType AS Typ_promocji
				,CONCAT(C.FirstName,'' '', C.LastName) AS Klient
				,C.Gender AS Plec
				,YEAR(F.OrderDate) AS Rok 
				,MONTH(F.OrderDate) AS Miesiac
				,F.ProductStandardCost AS Koszt_produktu
				,F.SalesAmount AS Wartosc_sprzedazy
				,''Internet'' AS Rodzaj
			FROM 
			[dbo].[FactInternetSales] AS F
			LEFT JOIN DimCustomer AS C
				ON C.CustomerKey = F.CustomerKey
			LEFT JOIN DimPromotion AS Prom
				ON F.PromotionKey = Prom.PromotionKey
			WHERE 1=1 '
			IF @Kategotia_promocji IS NOT NULL AND (@Rodzaj = 'Internet' OR @Rodzaj IS NULL)
				SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'AND Prom.EnglishPromotionCategory = @Kategotia_promocji'
			IF @Typ_promocji IS NOT NULL  AND (@Rodzaj = 'Internet' OR @Rodzaj IS NULL)
				SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'AND Prom.EnglishPromotionType = @Typ_promocji'
			IF @Plec IS NOT NULL  AND (@Rodzaj = 'Internet' OR @Rodzaj IS NULL)
				SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'AND C.Gender = @Plec'
			IF @Klient IS NOT NULL  AND (@Rodzaj = 'Internet' OR @Rodzaj IS NULL)
				SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'AND CONCAT(C.FirstName,'' '', C.LastName) = @Klient'
			IF @Rok IS NOT NULL  AND (@Rodzaj = 'Internet' OR @Rodzaj IS NULL)
				SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'AND YEAR(F.OrderDate) = @Rok'
			IF @Miesiac IS NOT NULL  AND (@Rodzaj = 'Internet' OR @Rodzaj IS NULL)
				SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'AND MONTH(F.OrderDate) = @Miesiac'

		IF @Rodzaj IS  NULL
			SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'UNION ALL'

		IF @Rodzaj = 'Po�rednia' OR @Rodzaj IS NULL
			SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'SELECT  
				Prom.EnglishPromotionCategory AS Kategotia_promocji
				,Prom.EnglishPromotionType AS Typ_promocji
				,''N/D'' AS Klient
				,''N/D'' AS Plec
				,YEAR(F.OrderDate) AS Rok 
				,MONTH(F.OrderDate) AS Miesiac
				,F.ProductStandardCost AS Koszt_produktu
				,F.SalesAmount AS Wartosc_sprzedazy
				,''Po�rednia'' AS Rodzaj
			FROM 
			[dbo].[FactResellerSales] AS F

			LEFT JOIN DimPromotion AS Prom
				ON F.PromotionKey = Prom.PromotionKey
			WHERE 1=1 '
			IF @Kategotia_promocji IS NOT NULL AND (@Rodzaj = 'Po�rednia' OR @Rodzaj IS NULL)
				SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'AND Prom.EnglishPromotionCategory = @Kategotia_promocji'
			IF @Typ_promocji IS NOT NULL AND (@Rodzaj = 'Po�rednia' OR @Rodzaj IS NULL)
				SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'AND Prom.EnglishPromotionType = @Typ_promocji'
			IF @Rok IS NOT NULL AND (@Rodzaj = 'Po�rednia' OR @Rodzaj IS NULL)
				SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'AND YEAR(F.OrderDate) = @Rok'
			IF @Miesiac IS NOT NULL AND (@Rodzaj = 'Po�rednia' OR @Rodzaj IS NULL)
				SET @SQL = @SQL + CHAR(13) + CHAR(10) + 'AND MONTH(F.OrderDate) = @Miesiac'

		SET @SQL = @SQL + '
		)

		SELECT 
			Kategotia_promocji
			,Typ_promocji
			,Klient
			,Plec
			,Rok 
			,Miesiac
			,Rodzaj
			, SUM(Koszt_produktu) AS Koszt_produktu
			, SUM(Wartosc_sprzedazy) AS Wartosc_sprzedazy
		FROM fakty
		GROUP BY 
			 Kategotia_promocji
			,Typ_promocji
			,Klient
			,Plec
			,Rok 
			,Miesiac
			,Rodzaj
		ORDER BY Rok, Miesiac
		OPTION(RECOMPILE)
		'

	--Wykonanie kodu
	IF @Debug = 0 
	BEGIN
		Execute sp_Executesql  @SQL, 
							   @ParamDefinition,
							   @Rok,
							   @Miesiac,
							   @Kategotia_promocji,
							   @Typ_promocji,
							   @Plec, 
							   @Klient
							
							  
							  
							   
							   

	If @@ERROR <> 0 GoTo ErrorHandler
    Set NoCount OFF
    Return(0)
	
	ErrorHandler:
    Return(@@ERROR)
	END

	IF @Debug = 1
		PRINT  @SQL


GO













--Wyczy��my cache plan
dbcc freeproccache
GO 






-- Przetestujmy nasz� procedur�






EXEC	[dbo].[usp_Raport_sprzedazy]
		@Rodzaj = N'Internet',
		@Rok = N'2014',
		@Debug = 0
GO


EXEC	[dbo].[usp_Raport_sprzedazy]
		@Rodzaj = N'Internet',
		@Rok = N'2014',
		@Miesiac = N'1',
		@Debug = 0
GO 

EXEC	[dbo].[usp_Raport_sprzedazy]
		
		@Rok = N'2014',
		@Miesiac = N'1',
		@Debug = 0

EXEC	[dbo].[usp_Raport_sprzedazy]
		
		@Rok = N'2014',
		@Plec = 'F',
		@Debug = 0
GO 

EXEC	[dbo].[usp_Raport_sprzedazy]  --por�wnaj plan z poprzednim przyk�adem
		
		@Rok = N'2013',
		@Debug = 0
GO 


-- zobaczmy jak teraz wygl�da cache plan

select 
	st.text,*
from sys.dm_exec_cached_plans cp
	cross apply sys.dm_exec_sql_text(cp.plan_handle) st
where 
	(st.text like '%FROM fakty%')
	and st.text not like '%select st.text%'
GO 