--4 Analysis of Variance
USE PredictiveMaintenance;
GO

/*******************************************************************************************************************
From correlation analysis it turned out that Gear is the most likely failure as device age increases. 
Let's investigate the distribuition of failures with respect to two cases: a) device is still in warranty, b) device is out of warranty. 
The output is a STRIPCHART, where we can evidence of the values distribution around the two cases: 
0 = no warranty / 1 = warranty
*******************************************************************************************************************/
EXEC sys.sp_execute_external_script
	@language = N'R'
	,@script = N'
		imageDir <- ''C:\\Temp\\Rplot''
		image_filename = tempfile(pattern = "gear_warranty_plot_", tmpdir = imageDir, fileext = ".jpg")
		print(image_filename)
		jpeg(filename=image_filename, width=600, height = 900)
		print(stripchart(TotFailure ~ Warranty, vertical = TRUE, pch = 3, data = InputDataSet, xlab = "Warranty (1 = yes / 0 = no)", ylab = "TotFailure", method = "jitter", jitter = 0.09))
		dev.off()
		OutputDataSet <- data.frame(data=readBin(file(image_filename, "rb"), what=raw(), n=1e6))
		'
	,@input_data_1 = N'
		SELECT 
		CAST(FailureDate AS nvarchar(12)) AS FailureDate,
		COUNT(*) AS TotFailure,
		CASE WHEN DATEDIFF(mm,WarrantyDate,GETDate()) <= 24 THEN 1 ELSE 0 END AS Warranty
		FROM dbo.ProductFailure pf
		WHERE FailureCode = ''B-600''
		GROUP BY FailureDate, CASE WHEN DATEDIFF(mm,WarrantyDate,GETDate()) <= 24 THEN 1 ELSE 0 END
		'
WITH RESULT SETS((plot varbinary(max)));

