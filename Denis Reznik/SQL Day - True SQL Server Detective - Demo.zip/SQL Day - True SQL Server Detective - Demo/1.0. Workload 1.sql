USE Twitter
GO

-- Note: Disable STATISTICS for this session in SSMS

-- Note: Do not forget to run the preparation script



























BEGIN TRAN

UPDATE Users SET cached_date = GETDATE()
WHERE Id = 87548056

