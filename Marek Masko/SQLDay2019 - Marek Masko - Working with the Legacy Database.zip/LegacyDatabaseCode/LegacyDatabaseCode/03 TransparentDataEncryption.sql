USE [master]; 
GO 





/* Check for Database Master Key */
SELECT 
  [name] AS [KeyName] 
, [symmetric_key_id] AS [KeyID] 
, [key_length] AS [KeyLength] 
, [algorithm_desc] AS [KeyAlgorithm] 
, [create_date] AS [CreatedDate] 
, [modify_date] AS [ModifyDate] 
FROM [master].[sys].[symmetric_keys]; 





/* Create Master Key */
CREATE MASTER KEY 
ENCRYPTION BY PASSWORD = 'Enter_Strong_P@ssw0rd1!_Here'; 





/* Check for Certificate */
SELECT 
  [name] AS [CertName] 
, [certificate_id] AS [CertID] 
, [pvt_key_encryption_type_desc] AS [EncryptType] 
, [issuer_name] AS [Issuer] 
, [subject] AS [Subject] 
, [start_date] AS [StartDate] 
, [expiry_date] AS [ExpiryDate] 
FROM [master].[sys].[certificates];





/* Create Certificate */
CREATE CERTIFICATE TDECertificate 
WITH SUBJECT = 'Certificate used for TDE';





/* Backup Certificate */
BACKUP CERTIFICATE TDECertificate TO FILE = 'C:\Temp\TDECertificate.cert'   
WITH PRIVATE KEY ( FILE = 'C:\Temp\TDECertificate_PK.key',    
ENCRYPTION BY PASSWORD = 'Enter_Strong_P@ssw0rd1!_For_Backup_Here');   
GO  





USE [TameTheBeast];
GO 
  
/* Create Database Encryption Key */
CREATE DATABASE ENCRYPTION KEY 
WITH ALGORITHM = AES_256 
ENCRYPTION BY SERVER CERTIFICATE TDECertificate;





/* Enable Encryption */
ALTER DATABASE [TameTheBeast] SET ENCRYPTION on; 





/* Check Encryption state */
SELECT DB_NAME(d.database_id) db, d.state_desc, 
case dek.encryption_state  
when 0 then 'No database encryption key present'  
when 1 then 'Unencrypted'  
when 2 then 'Encryption in progress' 
when 3 then 'Encrypted' 
when 4 then 'Key change in progress' 
when 5 then 'Decryption in progress' 
when 6 then 'Protection change in progress' 
end as EncryptionStatus, 
c.name as CertName, 
dek.percent_complete 
from sys.dm_database_encryption_keys dek 
left join sys.certificates c 
on dek.encryptor_thumbprint = c.thumbprint 
right join sys.databases d 
on dek.database_id = d.database_id 
and d.state_desc = 'ONLINE' 


/* Cleanup

USE [TameTheBeast]; -- enter database name here 
GO 

ALTER DATABASE [TameTheBeast] SET ENCRYPTION off; 
GO

DROP DATABASE ENCRYPTION KEY; 
GO

USE [master]; 
GO 

DROP CERTIFICATE TDECertificate; 
GO

DROP MASTER KEY;
GO
--*/