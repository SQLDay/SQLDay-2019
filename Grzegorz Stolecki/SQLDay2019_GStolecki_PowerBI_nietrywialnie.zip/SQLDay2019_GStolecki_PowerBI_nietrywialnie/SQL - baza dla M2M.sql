use master;
go

drop database if exists TestM2M;
go

create database TestM2M;
go

use TestM2M;
go

create table Konta(
	Konto nvarchar(10));
go
insert Konta values ('Konto 1'), ('Konto 2'), ('Konto 3');
select * from Konta;

create table Osoby(
	Osoba nvarchar(10));
go
insert Osoby values ('Adam'), ('Beata'), ('Dariusz');
select * from Osoby;

create table WlascicieleKont(
	Osoba nvarchar(10), Konto nvarchar(10));
go
insert WlascicieleKont values
	('Adam', 'Konto 1'),
	('Beata', 'Konto 1'),
	('Beata', 'Konto 2'),
	('Dariusz' , 'Konto 3')
select * from WlascicieleKont;

create table Wplaty(
	Konto nvarchar(10), Kwota int);
go
insert Wplaty values
	('Konto 1', 100), ('Konto 2', 200), ('Konto 3', 300),
	('Konto 1', 50), ('Konto 2', 70), ('Konto 3', 100)
select * from Wplaty;

