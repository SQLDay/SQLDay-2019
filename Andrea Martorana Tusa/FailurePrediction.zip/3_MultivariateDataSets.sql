--3 Multivariate data sets
USE PredictiveMaintenance;
GO

/****************************************************************************************************************************************************************
The dataset has multiple variables as there are many different kind of failures: frame, brakes, wheels, etc.  
With an SQL script we convert the original dataset to a table suitable as data frame in R in order to perform some multivariate analysis on it. 
******************************************************************************************************************************************************************/
--convert the original table into a pivot to pass to R
CREATE OR ALTER VIEW dbo.vw_PivotAgeDes
AS 
SELECT 
	DATEDIFF(MM,ProductionDate,GETDATE()) AS AgeMonth,
	SUM(CASE WHEN FailureDescription = 'Brake' THEN 1 ELSE 0 END) AS Brake,
	SUM(CASE WHEN FailureDescription = 'Frame' THEN 1 ELSE 0 END) AS Frame,
	SUM(CASE WHEN FailureDescription = 'Pedal' THEN 1 ELSE 0 END) AS Pedal,
	SUM(CASE WHEN FailureDescription = 'Chain' THEN 1 ELSE 0 END) AS Chain,
	SUM(CASE WHEN FailureDescription = 'Wheel rim' THEN 1 ELSE 0 END) AS WheelRim,
	SUM(CASE WHEN FailureDescription = 'Gear' THEN 1 ELSE 0 END) AS Gear
FROM dbo.vw_ProductFailure
WHERE FailureDescription IN ('Brake','Frame','Pedal','Chain','Wheel rim','Gear')
GROUP BY DATEDIFF(MM,ProductionDate,GETDATE());
GO
 
--First analysis: linear regression model for every type of failure 
EXEC sp_execute_external_script
@language =N'R'
, @script = N'
	library(RevoScaleR)
	df <- data.frame(rxImport(InputDataSet))
	imageDir <- ''C:\\Temp\\Rplot'';
	image_filename = tempfile(pattern = "scatter_variables_plot_", tmpdir = imageDir, fileext = ".jpg");
	print(image_filename);
	jpeg(filename=image_filename, width=600, height = 900);
	print(plot(df));
	dev.off();
	OutputDataSet <- data.frame(data=readBin(file(image_filename, "rb"), what=raw(), n=1e6));
	'	
, @input_data_1= N'SELECT * FROM dbo.vw_PivotAgeDes'
, @output_data_1_name = N'OutputDataSet'
WITH RESULT SETS ((plot varbinary(max)));


--Let's examine the relationship between age and brakes using a regression model. 
--Calculate the model and plot it. 
EXEC sys.sp_execute_external_script
	@language = N'R'
	,@script = N'
		library(RevoScaleR)
		brakemodel <- lm(AgeMonth~Brake, data = InputDataSet)
		imageDir <- ''C:\\Temp\\Rplot'';
		image_filename = tempfile(pattern = "brakes_model_plot_", tmpdir = imageDir, fileext = ".jpg");
		print(image_filename);
		jpeg(filename=image_filename, width=600, height = 900);
		print(plot(brakemodel));
		dev.off();
		OutputDataSet <- data.frame(data=readBin(file(image_filename, "rb"), what=raw(), n=1e6));
		'
	,@input_data_1 = N'SELECT * FROM dbo.vw_PivotAgeDes'
WITH RESULT SETS((plot varbinary(max)));

/******************************************************************************************************************************
The standard set of plots for a fitted linear model is made of four plots. 
By default they are shown one at a time; To view them all at once, is it possible to use the par function 
with the mfrow parameter to specify a 2 x 2 layout:
*********************************************************************************************************************************/
EXEC sys.sp_execute_external_script
	@language = N'R'
	,@script = N'
		library(RevoScaleR)
		brakemodel <- lm(AgeMonth~Brake, data = InputDataSet)
		imageDir <- ''C:\\Temp\\Rplot'';
		image_filename = tempfile(pattern = "brakes_model_plot_", tmpdir = imageDir, fileext = ".jpg");
		print(image_filename);
		jpeg(filename=image_filename, width=600, height = 900);
		par(mfrow=c(2,2));
		print(plot(brakemodel));
		dev.off();
		OutputDataSet <- data.frame(data=readBin(file(image_filename, "rb"), what=raw(), n=1e6));
		'
	,@input_data_1 = N'SELECT * FROM dbo.vw_PivotAgeDes'
WITH RESULT SETS((plot varbinary(max)));

--1) Residuals vs Fitted values. Residual = Observed � Predicted. This plot shows if residuals have non-linear patterns
--2) Normal Q-Q of standardized residuals. This plot shows if residuals are normally distributed
--3) Scale-Location plot; square roots of standardized residuals versus fitted values. This plot shows if residuals are spread equally along the ranges of predictors
--4) Residuals vs Leverage. This plot helps us to find influential cases if any. Extreme values might not be influential to determine a regression line

--Extract coefficient values from the model. lm fits the linear model
EXEC sys.sp_execute_external_script
	@language = N'R'
	,@script = N'
		library(RevoScaleR)
		brakemodel <- lm(AgeMonth~Brake, data = InputDataSet)
		OutputDataSet <- data.frame(coef(brakemodel))
		'
	,@input_data_1 = N'SELECT * FROM dbo.vw_PivotAgeDes'
WITH RESULT SETS((CorrelationCoefficients decimal(12,8)));

--Visualize correlations for age and each type of failure
EXEC sys.sp_execute_external_script
	@language = N'R'
	,@script = N'
		pvt_fail <- InputDataSet
		df_pvt_fail <- data.frame(pvt_fail)
		cor_Brake <- cor(df_pvt_fail$Brake, df_pvt_fail$AgeMonth)
		cor_Frame <- cor(df_pvt_fail$Frame, df_pvt_fail$AgeMonth)
		cor_Pedal <- cor(df_pvt_fail$Pedal, df_pvt_fail$AgeMonth)
		cor_Chain <- cor(df_pvt_fail$Chain, df_pvt_fail$AgeMonth)
		cor_WheelRim <- cor(df_pvt_fail$WheelRim, df_pvt_fail$AgeMonth)
		cor_Gear <- cor(df_pvt_fail$Gear, df_pvt_fail$AgeMonth)
		out_df <- data.frame(cbind(cor_Brake,cor_Frame,cor_Pedal,cor_Chain,cor_WheelRim,cor_Gear))
		OutputDataSet <- out_df
	'
	,@input_data_1 = N'SELECT * FROM dbo.vw_PivotAgeDes'
	WITH RESULT SETS((
		cor_Brake	numeric(10,3),
		cor_Frame	numeric(10,3),
		cor_Pedal	numeric(10,3),
		cor_Chain	numeric(10,3),
		cor_WheelRim numeric(10,3),
		cor_Gear	numeric(10,3)
	));

--The highest correlation is for gears. We will investigate it further on. 

--------------------------------output for PowerBI with rows transposed as columns
EXEC sys.sp_execute_external_script
	@language = N'R'
	,@script = N'
		pvt_fail <- InputDataSet
		df_pvt_fail <- data.frame(pvt_fail)
		cor_Brake <- cor(df_pvt_fail$Brake, df_pvt_fail$AgeMonth)
		cor_Frame <- cor(df_pvt_fail$Frame, df_pvt_fail$AgeMonth)
		cor_Pedal <- cor(df_pvt_fail$Pedal, df_pvt_fail$AgeMonth)
		cor_Chain <- cor(df_pvt_fail$Chain, df_pvt_fail$AgeMonth)
		cor_WheelRim <- cor(df_pvt_fail$WheelRim, df_pvt_fail$AgeMonth)
		cor_Gear <- cor(df_pvt_fail$Gear, df_pvt_fail$AgeMonth)
		out_df <- data.frame(cbind(rbind("Brake","Frame","Pedal","Chain","WheelRim","Gear"),
			rbind(cor_Brake,cor_Frame,cor_Pedal,cor_Chain,cor_WheelRim,cor_Gear)))
		OutputDataSet <- out_df
	'
	,@input_data_1 = N'SELECT * FROM dbo.vw_PivotAgeDes'
	WITH RESULT SETS((
		component nvarchar(50),
		cor_coeff	numeric(10,3)
	));
---------------------------------------------------------------------------------------------------------

/*******************************************************************************************************************
We want to plot the diagram of correlations between variables. 
This is done by invoking the package CORRPLOT for graphical display of a correlation matrix or general matrix.

NB: code available from the corrplot documentation
********************************************************************************************************************/
EXEC sys.sp_execute_external_script
	@language = N'R'
	,@script = N'
		library(corrplot)
		pvt_fail <- InputDataSet
		cor.mtest <- function(mat, ...) {
			mat <- as.matrix(mat)
			n <- ncol(mat)
			p.mat<- matrix(NA, n, n)
			diag(p.mat) <- 0
			for (i in 1:(n - 1)) {
				for (j in (i + 1):n) {
				tmp <- cor.test(mat[, i], mat[, j], ...)
				p.mat[i, j] <- p.mat[j, i] <- tmp$p.value
				}
			}
			colnames(p.mat) <- rownames(p.mat) <- colnames(mat)
			p.mat
			}
		p.mat <- cor.mtest(pvt_fail)
		R <-cor(pvt_fail)
		col <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", "#77AADD", "#4477AA"))
		imageDir <- ''C:\\Temp\\Rplot'';
		image_filename = tempfile(pattern = "corrplot_", tmpdir = imageDir, fileext = ".jpg")
		print(image_filename)
		jpeg(filename = image_filename, width=600, height = 900)
		plot_corr <- corrplot(R, method="color", col=col(200), type="upper", order="hclust", addCoef.col = "black",
			tl.col="black", tl.srt=45, p.mat = p.mat, sig.level = 0.01, insig = "blank", diag=FALSE)
		print(plot_corr)
		dev.off(); 
		OutputDataSet <- data.frame(data=readBin(file(image_filename, "rb"), what=raw(), n=1e6));  '
	,@input_data_1 = N'SELECT * FROM dbo.vw_PivotAgeDes'
	WITH RESULT SETS ((
		correlation_plot varbinary(max)
		));

--Plot the same chart using Reporting Services
--Insert the sp output into a table and query the table from Reporting Services. 

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'RPlot' AND schema_id = 1) 
DROP TABLE dbo.RPlot;

CREATE TABLE [dbo].[RPlot](
	[plot] [varbinary](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

--Stored procedure to wrap all the steps into one single execution
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_RPlot' AND schema_id = 1)
DROP PROCEDURE dbo.usp_RPlot;
GO

CREATE OR ALTER PROCEDURE dbo.usp_RPlot
AS
BEGIN
	--Truncate destination table
	TRUNCATE TABLE dbo.RPlot

	--redirect the output from stored procedure into a table
	INSERT INTO dbo.RPlot (plot)
	EXEC sys.sp_execute_external_script
		@language = N'R'
		,@script = N'
			library(corrplot)
			pvt_fail <- InputDataSet
			cor.mtest <- function(mat, ...) {
				mat <- as.matrix(mat)
				n <- ncol(mat)
				p.mat<- matrix(NA, n, n)
				diag(p.mat) <- 0
				for (i in 1:(n - 1)) {
					for (j in (i + 1):n) {
					tmp <- cor.test(mat[, i], mat[, j], ...)
					p.mat[i, j] <- p.mat[j, i] <- tmp$p.value
					}
				}
				colnames(p.mat) <- rownames(p.mat) <- colnames(mat)
				p.mat
				}
			p.mat <- cor.mtest(pvt_fail)
			R <-cor(pvt_fail)
			col <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", "#77AADD", "#4477AA"))
			image_filename = tempfile()
			jpeg(filename = image_filename, width=600, height = 900)
			plot_corr <- corrplot(R, method="color", col=col(200), type="upper", order="hclust", addCoef.col = "black",
				tl.col="black", tl.srt=45, p.mat = p.mat, sig.level = 0.01, insig = "blank", diag=FALSE)
			print(plot_corr)
			dev.off(); 
			OutputDataSet <- data.frame(data=readBin(file(image_filename, "rb"), what=raw(), n=1e6));  
			'
		,@input_data_1 = N'SELECT * FROM dbo.vw_PivotAgeDes'


	--query the destination table
	SELECT TOP 1 plot FROM dbo.RPlot

END
GO

--Test the sp
EXEC dbo.usp_RPlot


--Stored procedure to calculate correlation coefficient for all components into one single execution. Invoked by Reporting Services.
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_CorrCoeff' AND schema_id = 1)
DROP PROCEDURE dbo.usp_CorrCoeff;
GO

CREATE PROCEDURE dbo.usp_CorrCoeff
AS
BEGIN
EXEC sys.sp_execute_external_script
	@language = N'R'
	,@script = N'
		pvt_fail <- InputDataSet
		df_pvt_fail <- data.frame(pvt_fail)
		cor_Brake <- cor(df_pvt_fail$Brake, df_pvt_fail$AgeMonth)
		cor_Frame <- cor(df_pvt_fail$Frame, df_pvt_fail$AgeMonth)
		cor_Pedal <- cor(df_pvt_fail$Pedal, df_pvt_fail$AgeMonth)
		cor_Chain <- cor(df_pvt_fail$Chain, df_pvt_fail$AgeMonth)
		cor_WheelRim <- cor(df_pvt_fail$WheelRim, df_pvt_fail$AgeMonth)
		cor_Gear <- cor(df_pvt_fail$Gear, df_pvt_fail$AgeMonth)
		out_df <- data.frame(cbind(cor_Brake,cor_Frame,cor_Pedal,cor_Chain,cor_WheelRim,cor_Gear))
		OutputDataSet <- out_df
	'
	,@input_data_1 = N'SELECT * FROM dbo.vw_PivotAgeDes'
	WITH RESULT SETS((
		cor_Brake	numeric(10,3),
		cor_Frame	numeric(10,3),
		cor_Pedal	numeric(10,3),
		cor_Chain	numeric(10,3),
		cor_WheelRim numeric(10,3),
		cor_Gear	numeric(10,3)
	));
END