USE [TameTheBeast];
GO

CREATE TABLE [dbo].[DatabaseUsageStats] (
  ID int IDENTITY (1,1) NOT NULL
, [SchemaName] nvarchar(128) NOT NULL
, [ObjectName] nvarchar(128) NOT NULL
, [ObjectType] nchar(1) NOT NULL
, [LastExecutionTime] datetime
, [ExecutionCount] bigint
, [CumExecutionCount] bigint
, [IndexId] int
, [IndexName] nvarchar(128)
, [UserSeeks] bigint
, [UserScans] bigint
, [UserLookups] bigint
, [UserUpdates] bigint
, [CumUserSeeks] bigint
, [CumUserScans] bigint
, [CumUserLookups] bigint
, [CumUserUpdates] bigint
, [LastUserSeek] datetime
, [LastUserScan] datetime
, [LastUserLookup] datetime
, [LastUserUpdate] datetime
, [CreateStatement] nvarchar(max)
, [RowInsertedTime] datetime NOT NULL
, [RowUpdatedTime] datetime NOT NULL
, [SqlServerStartTime] datetime NOT NULL
, CONSTRAINT [PK_DatabaseUsageStats] PRIMARY KEY CLUSTERED ( [ID] ASC )
) 
GO

CREATE NONCLUSTERED INDEX [IX_DatabaseUsageStats_SchemaObjectIndex] ON [dbo].[DatabaseUsageStats]
(
	[ObjectType] ASC
)
INCLUDE ([ID],[SchemaName],[ObjectName],[IndexName]) 
GO

CREATE PROCEDURE [dbo].[usp_SaveDatabaseUsageStats]
AS
BEGIN 
	SET NOCOUNT ON;

	-- Create temp tables
	CREATE TABLE #TableUsageData (
	  [SchemaName] nvarchar(128)
	, [ObjectName] nvarchar(128)
	, [IndexId] int
	, [IndexName] nvarchar(128)
	, [UserSeeks] bigint
	, [UserScans] bigint
	, [UserLookups] bigint
	, [UserUpdates] bigint
	, [LastUserSeek] datetime
	, [LastUserScan] datetime
	, [LastUserLookup] datetime
	, [LastUserUpdate] datetime
	, [CreateStatement] nvarchar(max)
	);

	CREATE TABLE #ProcedureUsageData (
	  [SchemaName] nvarchar(128)
	, [ObjectName] nvarchar(128)
	, [LastExecutionTime] datetime
	, [ExecutionCount] bigint
	);

	DECLARE @SqlServerStartTime datetime;
	SET @SqlServerStartTime = (SELECT TOP(1) sqlserver_start_time FROM sys.dm_os_sys_info);

	DECLARE @RunTime datetime;
	SET @RunTime = GETDATE();

	-- Populate temp tables

	INSERT #TableUsageData
	SELECT
	  sc.name AS [SchemaName]
	, t.name AS [ObjectName]
	, si.index_id AS [IndexId]
	, COALESCE(si.name, N'HEAP_NO_INDEX') AS [IndexName]
	, stat.user_seeks AS [UserSeeks]
	, stat.user_scans AS [UserScans]
	, stat.user_lookups AS [UserLookups]
	, stat.user_updates AS [UserUpdates]
	, stat.last_user_seek AS [LastUserSeek]
	, stat.last_user_scan AS [LastUserScan]
	, stat.last_user_lookup AS [LastUserLookup]
	, stat.last_user_update AS [LastUserUpdate]
	, CASE si.index_id WHEN 0 THEN N'HEAP_NO_INDEX'
	ELSE 
		CASE is_primary_key WHEN 1 THEN
			N'ALTER TABLE ' + QUOTENAME(sc.name) + N'.' + QUOTENAME(t.name) + N' ADD CONSTRAINT ' + QUOTENAME(si.name) + N' PRIMARY KEY ' +
				CASE WHEN si.index_id > 1 THEN N'NON' ELSE N'' END + N'CLUSTERED '
		ELSE N'CREATE ' + 
			CASE WHEN si.is_unique = 1 THEN N'UNIQUE ' ELSE N'' END +
			CASE WHEN si.index_id > 1  THEN N'NON' ELSE N'' END + N'CLUSTERED ' +
			N'INDEX ' + QUOTENAME(si.name) + N' ON ' + QUOTENAME(sc.name) + N'.' + QUOTENAME(t.name) + N' '
		END +
		/* Definition of columns */ N'(' + key_definition + N')' +
		/* Definition of included columns */ CASE WHEN include_definition IS NOT NULL THEN N' INCLUDE (' + include_definition + N')' ELSE N'' END +
		/* Definition of index filters */ CASE WHEN filter_definition IS NOT NULL THEN N' WHERE ' + filter_definition ELSE N'' END +
		/* Definition of compression */
		CASE WHEN row_compression_partition_list IS NOT NULL OR page_compression_partition_list IS NOT NULL
			 THEN N' WITH (' +
				CASE WHEN row_compression_partition_list IS NOT NULL THEN N'DATA_COMPRESSION = ROW ' +
					CASE WHEN psc.name IS NULL THEN N'' ELSE + N' ON PARTITIONS (' + row_compression_partition_list + N')' END
				ELSE N'' END +
				CASE WHEN row_compression_partition_list IS NOT NULL AND page_compression_partition_list IS NOT NULL THEN N', ' ELSE N'' END +
				CASE WHEN page_compression_partition_list IS NOT NULL THEN N'DATA_COMPRESSION = PAGE ' +
					CASE WHEN psc.name IS NULL THEN N'' ELSE + N' ON PARTITIONS (' + page_compression_partition_list + N')' END
				ELSE N'' END
			+ N')'
			ELSE N''
		END +
		/* Definition of index storage: Filegroup OR Partition scheme */
		' ON ' + CASE WHEN psc.name IS NULL THEN ISNULL(QUOTENAME(fg.name),N'') ELSE psc.name + N' (' + partitioning_column.column_name + N')' END + N';'
	END AS [CreateStatement]

	FROM sys.indexes AS si
	JOIN sys.tables AS t ON (si.[object_id]=t.[object_id])
	JOIN sys.schemas AS sc ON t.[schema_id]=sc.[schema_id]
	LEFT JOIN sys.dm_db_index_usage_stats AS stat ON (stat.database_id = DB_ID() AND si.[object_id]=stat.[object_id] AND si.index_id=stat.index_id)
	LEFT JOIN sys.partition_schemes AS psc ON (si.data_space_id=psc.data_space_id)
	LEFT JOIN sys.partition_functions AS pf ON (psc.function_id=pf.function_id)
	LEFT JOIN sys.filegroups AS fg ON (si.data_space_id=fg.data_space_id)

	/* Definition of columns */ OUTER APPLY ( SELECT STUFF (
	(SELECT N', ' + QUOTENAME(c.name) + CASE ic.is_descending_key WHEN 1 THEN N' DESC' ELSE N' ASC' END
	FROM sys.index_columns AS ic
	INNER JOIN sys.columns AS c ON (ic.column_id=c.column_id AND ic.[object_id]=c.[object_id])
	WHERE (ic.[object_id] = si.[object_id] AND ic.index_id=si.index_id AND ic.key_ordinal > 0)
	ORDER BY ic.key_ordinal FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,2,'')) AS keys (key_definition)

	/* Partitioning Order */ OUTER APPLY (
	SELECT MAX(QUOTENAME(c.name)) AS column_name
	FROM sys.index_columns AS ic 
	INNER JOIN sys.columns AS c ON (ic.column_id=c.column_id AND ic.[object_id]=c.[object_id])
	WHERE (ic.[object_id] = si.[object_id] AND ic.index_id=si.index_id AND ic.partition_ordinal = 1) ) AS partitioning_column

	/* Definition of included columns */ OUTER APPLY ( SELECT STUFF (
	(SELECT N', ' + QUOTENAME(c.name)
	FROM sys.index_columns AS ic 
	INNER JOIN sys.columns AS c ON (ic.column_id=c.column_id AND ic.[object_id]=c.[object_id])
	WHERE (ic.[object_id] = si.[object_id] AND ic.index_id=si.index_id AND ic.is_included_column = 1)
	ORDER BY c.name FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,2,'')) AS includes (include_definition)

	/* Row compression */ OUTER APPLY ( SELECT STUFF (
	(SELECT N', ' + CAST(p.partition_number AS VARCHAR(32))
	FROM sys.partitions AS p
	WHERE (p.[object_id] = si.[object_id] AND p.index_id=si.index_id AND p.[data_compression] = 1)
	ORDER BY p.partition_number FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,2,'')) AS row_compression_clause (row_compression_partition_list)

	/* Data compression by partition */ OUTER APPLY ( SELECT STUFF (
	(SELECT N', ' + CAST(p.partition_number AS VARCHAR(32))
	FROM sys.partitions AS p
	WHERE (p.[object_id] = si.[object_id] AND p.index_id=si.index_id AND p.[data_compression] = 2)
	ORDER BY p.partition_number FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,2,'')) AS page_compression_clause (page_compression_partition_list)
	WHERE (si.[type] IN (0,1,2) /* heap, clustered, nonclustered */ AND si.is_hypothetical = 0)
	ORDER BY [ObjectName], si.index_id
	OPTION (RECOMPILE)

	INSERT #ProcedureUsageData
	SELECT
	  OBJECT_SCHEMA_NAME (P.[object_id], DB_ID()) AS [SchemaName]
	, P.name AS [ObjectName]
	, S.last_execution_time AS [LastExecutionTime]
	, COALESCE(S.execution_count,0) AS [ExecutionCount]
	FROM sys.procedures P
	LEFT JOIN sys.dm_exec_procedure_stats S ON (S.[object_id] = P.[object_id] AND S.database_id = DB_ID())


	-- UPDATE TABLE DATA


	-- CASE 1: The same index name, the same columns
	UPDATE [dbo].[DatabaseUsageStats] SET
	  [SqlServerStartTime] = @SqlServerStartTime
	, [LastUserSeek] = COALESCE(c.[LastUserSeek], p.[LastUserSeek])
	, [LastUserScan] = COALESCE(c.[LastUserScan], p.[LastUserScan])
	, [LastUserLookup] = COALESCE(c.[LastUserLookup], p.[LastUserLookup])
	, [LastUserUpdate] = COALESCE(c.[LastUserUpdate], p.[LastUserUpdate])
	, [RowUpdatedTime] = @RunTime
	, [UserSeeks] = COALESCE(c.[UserSeeks], 0)
	, [UserScans] = COALESCE(c.[UserScans], 0)
	, [UserLookups] = COALESCE(c.[UserLookups], 0)
	, [UserUpdates] = COALESCE(c.[UserUpdates], 0)

	, [CumUserSeeks] = CASE
		WHEN (@SqlServerStartTime =  p.[SqlServerStartTime] AND c.[UserSeeks] >= p.[UserSeeks]) THEN p.[CumUserSeeks] + (c.[UserSeeks] - p.[UserSeeks])
		WHEN (@SqlServerStartTime =  p.[SqlServerStartTime] AND c.[UserSeeks] <  p.[UserSeeks]) THEN p.[CumUserSeeks] + COALESCE(c.[UserSeeks],0)
		WHEN  @SqlServerStartTime <> p.[SqlServerStartTime] THEN COALESCE(p.[CumUserSeeks],0) + (COALESCE(c.[UserSeeks],0))
		ELSE COALESCE([CumUserSeeks],0)
	  END
	, [CumUserScans] = CASE
		WHEN (@SqlServerStartTime =  p.[SqlServerStartTime] AND c.[UserScans] >= p.[UserScans]) THEN p.[CumUserScans] + (c.[UserScans] - p.[UserScans])
		WHEN (@SqlServerStartTime =  p.[SqlServerStartTime] AND c.[UserScans] <  p.[UserScans]) THEN p.[CumUserScans] + COALESCE(c.[UserScans],0)
		WHEN  @SqlServerStartTime <> p.[SqlServerStartTime] THEN COALESCE(p.[CumUserScans],0) + (COALESCE(c.[UserScans],0))
		ELSE COALESCE([CumUserScans],0)
	  END
	, [CumUserLookups] = CASE
		WHEN (@SqlServerStartTime =  p.[SqlServerStartTime] AND c.[UserLookups] >= p.[UserLookups]) THEN p.[CumUserLookups] + (c.[UserLookups] - p.[UserLookups])
		WHEN (@SqlServerStartTime =  p.[SqlServerStartTime] AND c.[UserLookups] <  p.[UserLookups]) THEN p.[CumUserLookups] + COALESCE(c.[UserLookups],0)
		WHEN  @SqlServerStartTime <> p.[SqlServerStartTime] THEN COALESCE(p.[CumUserLookups],0) + (COALESCE(c.[UserLookups],0))
		ELSE COALESCE([CumUserLookups],0)
	  END
	, [CumUserUpdates] = CASE
		WHEN (@SqlServerStartTime  = p.[SqlServerStartTime] AND c.[UserUpdates] >= p.[UserUpdates]) THEN p.[CumUserUpdates] + (c.[UserUpdates] - p.[UserUpdates])
		WHEN (@SqlServerStartTime  = p.[SqlServerStartTime] AND c.[UserUpdates] <  p.[UserUpdates]) THEN p.[CumUserUpdates] + COALESCE(c.[UserUpdates],0)
		WHEN  @SqlServerStartTime <> p.[SqlServerStartTime] THEN COALESCE(p.[CumUserUpdates],0) + (COALESCE(c.[UserUpdates],0))
		ELSE COALESCE([CumUserUpdates],0)
	  END
	FROM [dbo].[DatabaseUsageStats] p
	INNER JOIN ( -- Make sure to update only current version
		SELECT MAX(ID) AS MaxIDVersion
		FROM [dbo].[DatabaseUsageStats] u
		WHERE u.ObjectType = 'T'
		GROUP BY SchemaName, ObjectName, IndexName
	) CurrVer ON CurrVer.MaxIDVersion = p.ID
	INNER JOIN #TableUsageData c ON (c.SchemaName = p.SchemaName AND c.ObjectName = p.ObjectName AND c.IndexName = p.IndexName AND c.CreateStatement = p.CreateStatement)
	WHERE p.ObjectType = 'T'

	
	-- CASE 2: The same index name, but its latest version has different columns
	INSERT [dbo].[DatabaseUsageStats] (
	  [SchemaName]
	, [ObjectName]
	, [ObjectType]
	, [IndexId] 
	, [IndexName]
	, [UserSeeks]
	, [UserScans]
	, [UserLookups]
	, [UserUpdates]
	, [CumUserSeeks]
	, [CumUserScans]
	, [CumUserLookups]
	, [CumUserUpdates]
	, [LastUserSeek]
	, [LastUserScan]
	, [LastUserLookup]
	, [LastUserUpdate]
	, [CreateStatement]
	, [RowInsertedTime]
	, [RowUpdatedTime]
	, [SqlServerStartTime]
	)
	SELECT 
	  [SchemaName]
	, [ObjectName]
	, 'T' AS [ObjectType]
	, [IndexId]
	, [IndexName]
	, COALESCE([UserSeeks], 0)
	, COALESCE([UserScans], 0)
	, COALESCE([UserLookups], 0)
	, COALESCE([UserUpdates], 0)
	, COALESCE([UserSeeks], 0) AS [CumUserSeeks]
	, COALESCE([UserScans], 0) AS [CumUserScans]
	, COALESCE([UserLookups], 0) AS [CumUserLookups]
	, COALESCE([UserUpdates], 0) AS [CumUserUpdates]
	, [LastUserSeek]
	, [LastUserScan]
	, [LastUserLookup]
	, [LastUserUpdate]
	, [CreateStatement]
	, @RunTime AS [RowInsertedTime]
	, @RunTime AS [RowUpdatedTime]
	, @SqlServerStartTime AS [SqlServerStartTime]
	FROM #TableUsageData st
	WHERE EXISTS (
		SELECT 1
		FROM (
			SELECT CurrVer.MaxIDVersion, CurrVer.SchemaName, CurrVer.ObjectName, CurrVer.IndexName, CS.CreateStatement
			FROM (
				SELECT MAX(ID) AS MaxIDVersion, SchemaName, ObjectName, IndexName
				FROM [dbo].[DatabaseUsageStats] u
				WHERE u.ObjectType = 'T'
				GROUP BY SchemaName, ObjectName, IndexName
			) CurrVer
			INNER JOIN [dbo].[DatabaseUsageStats] CS ON (CS.ID = CurrVer.MaxIDVersion)
		) LatestVersion
		WHERE LatestVersion.SchemaName = st.SchemaName
		AND LatestVersion.ObjectName = st.ObjectName
		AND LatestVersion.IndexName = st.IndexName
		AND ISNULL(LatestVersion.CreateStatement, '') <> ISNULL(st.CreateStatement, '')
	)

	-- CASE 3: Newly introduced indexes (by name)
	INSERT [dbo].[DatabaseUsageStats] (
	  [SchemaName]
	, [ObjectName]
	, [ObjectType]
	, [IndexId] 
	, [IndexName]
	, [UserSeeks]
	, [UserScans]
	, [UserLookups]
	, [UserUpdates]
	, [CumUserSeeks]
	, [CumUserScans]
	, [CumUserLookups]
	, [CumUserUpdates]
	, [LastUserSeek]
	, [LastUserScan]
	, [LastUserLookup]
	, [LastUserUpdate]
	, [CreateStatement]
	, [RowInsertedTime]
	, [RowUpdatedTime]
	, [SqlServerStartTime]
	)
	SELECT 
	  [SchemaName]
	, [ObjectName]
	, 'T' AS [ObjectType]
	, [IndexId]
	, [IndexName]
	, COALESCE([UserSeeks], 0)
	, COALESCE([UserScans], 0)
	, COALESCE([UserLookups], 0)
	, COALESCE([UserUpdates], 0)
	, COALESCE([UserSeeks], 0) AS [CumUserSeeks]
	, COALESCE([UserScans], 0) AS [CumUserScans]
	, COALESCE([UserLookups], 0) AS [CumUserLookups]
	, COALESCE([UserUpdates], 0) AS [CumUserUpdates]
	, [LastUserSeek]
	, [LastUserScan]
	, [LastUserLookup]
	, [LastUserUpdate]
	, [CreateStatement]
	, @RunTime AS [RowInsertedTime]
	, @RunTime AS [RowUpdatedTime]
	, @SqlServerStartTime AS [SqlServerStartTime]
	FROM #TableUsageData st
	WHERE NOT EXISTS (
		SELECT 1
		FROM [dbo].[DatabaseUsageStats] u
		WHERE u.ObjectType = 'T'
		AND u.SchemaName = st.SchemaName
		AND u.ObjectName = st.ObjectName
		AND u.IndexName = st.IndexName)

	-- UPDATE PROCEDURE DATA

	-- Process existing data (PROCEDURE)
	UPDATE [dbo].[DatabaseUsageStats] SET
	  [SqlServerStartTime] = @SqlServerStartTime
	, [RowUpdatedTime] = @RunTime
	, [LastExecutionTime] = COALESCE(c.[LastExecutionTime], p.[LastExecutionTime])
	, [ExecutionCount] = COALESCE(c.[ExecutionCount], 0)
	, [CumExecutionCount] = CASE
		WHEN (@SqlServerStartTime =  p.[SqlServerStartTime] AND c.[ExecutionCount] >= p.[ExecutionCount]) THEN p.[CumExecutionCount] + (c.[ExecutionCount] - p.[ExecutionCount])
		WHEN (@SqlServerStartTime =  p.[SqlServerStartTime] AND c.[ExecutionCount] <  p.[ExecutionCount]) THEN p.[CumExecutionCount] + COALESCE(c.[ExecutionCount],0)
		WHEN  @SqlServerStartTime <> p.[SqlServerStartTime] THEN p.[CumExecutionCount] + (COALESCE(c.[ExecutionCount],0))
		ELSE [CumExecutionCount]
	  END
	FROM [dbo].[DatabaseUsageStats] p
	INNER JOIN #ProcedureUsageData c ON (c.SchemaName = p.SchemaName AND c.ObjectName = p.ObjectName)
	WHERE p.ObjectType = 'P'

	-- Process new data (PROCEDURE)
	INSERT [dbo].[DatabaseUsageStats] (
	  [SqlServerStartTime]
	, [SchemaName]
	, [ObjectName]
	, [ObjectType]
	, [LastExecutionTime]
	, [ExecutionCount]
	, [CumExecutionCount]
	, [RowInsertedTime]
	, [RowUpdatedTime]
	)
	SELECT
	  @SqlServerStartTime
	, [SchemaName]
	, [ObjectName]
	, 'P' AS [ObjectType]
	, [LastExecutionTime]
	, COALESCE([ExecutionCount], 0) AS [ExecutionCount]
	, COALESCE([ExecutionCount], 0) AS [CumExecutionCount]
	, @RunTime AS [RowInsertedTime]
	, @RunTime AS [RowUpdatedTime]
	FROM #ProcedureUsageData p
	WHERE NOT EXISTS (
		SELECT 1
		FROM [dbo].[DatabaseUsageStats] u
		WHERE u.ObjectType = 'P'
		AND u.SchemaName = p.SchemaName
		AND u.ObjectName = p.ObjectName)

	DROP TABLE #TableUsageData;
	DROP TABLE #ProcedureUsageData;
END
GO

USE [msdb]
GO


BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DatabaseUsageStats', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'exec usp_SaveDatabaseUsageStats', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.usp_SaveDatabaseUsageStats', 
		@database_name=N'TameTheBeast', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run every 1 day', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190508, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'b942aa89-b10b-40c8-9df5-8aa3a82802d8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


/*
EXEC msdb.dbo.sp_start_job @job_name = 'DatabaseUsageStats' 
GO

SELECT * FROM TameTheBeast.dbo.DatabaseUsageStats;
GO
--*/