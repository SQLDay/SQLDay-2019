#connection to SQL Server. Import data using a ODBC connection.
library(RevoScaleR)
sConnectStr <- "Driver={ODBC Driver 13 for SQL Server};Server=HQ1123\\SQLDEV2016;Database=PredictiveMaintenance;Trusted_Connection=Yes"
sQuery = "SELECT AgeMonth, TotFailure FROM dbo.vw_ProductFailureCountAge ORDER BY AgeMonth;"
sDS <-RxOdbcData(sqlQuery=sQuery, connectionString=sConnectStr)
#convert to data frame
df_sql <- data.frame(rxImport(sDS))
#show data. Observations = Rows; Variables = Columns
str(df_sql)

#Calculation of correlation coefficient using cor function. 
cor_coeff <- cor(df_sql$TotFailure, df_sql$AgeMonth)
cor_coeff

#calculate a simple linear regression model using function rxLinMod from the package RevoScaleR
form <- TotFailure ~ AgeMonth      #formula definition
FailLinMod <- rxLinMod(form, data = df_sql)   #generate the model
FailLinMod #show the content for the model
summary(FailLinMod) #more infos about the model

#fetch test age data from SQL Server
sQuery2 = "SELECT AgeMonth FROM dbo.AgeTestData;"
sDS2 <-RxOdbcData(sqlQuery=sQuery2, connectionString=sConnectStr)
#convert to data frame
age.df <- data.frame(rxImport(sDS2))
#show data
str(age.df)

#invoke a prediction function 
predicted.fail <- rxPredict(FailLinMod,age.df, predVarNames = "predFailure")
#bind together input and predicted values
predicted.ouput <- cbind(age.df, ceiling(predicted.fail))
#show data
predicted.ouput

#plot model adding a linear regression line
plot(TotFailure~AgeMonth, data=df_sql, xlab="Product age", ylab="Tot failure", main = "Product Age vs Tot Failure - trained model")
abline(lm(TotFailure~AgeMonth, data = df_sql))

#plot predicted output
plot(predFailure~AgeMonth, data=predicted.ouput, xlab="Product age", ylab="Tot failure pred", main = "Product Age vs Tot Failure - predicted values")
