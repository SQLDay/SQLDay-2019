USE [AdventureWorks2012_HeavyLoad]
GO

SET STATISTICS TIME, IO OFF

DECLARE @count int = 1;
DECLARE @sql nvarchar(1000);

WHILE @count <= 100000
BEGIN
	SET @sql = N'UPDATE [dbo].[Product' + CAST(@count AS nvarchar(20)) + '] SET [SellEndDate] = GETDATE();';
	EXEC(@sql);
	SET @count += 1;
END 