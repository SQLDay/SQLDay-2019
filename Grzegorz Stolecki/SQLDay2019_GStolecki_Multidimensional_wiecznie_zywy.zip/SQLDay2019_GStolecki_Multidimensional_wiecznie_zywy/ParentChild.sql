create database PC
go

use PC
go

create table Dim_Pozycje(
 ID int, 
 ID_Nadrz int, 
 Nazwa varchar(20))
 
insert Dim_Pozycje values
 (1,1,'Zysk netto'),
 (2,1,'Podatek'),
 (3,1,'Zysk brutto'),
 (4,3,'Przychody'),
 (5,3,'Koszty'),
 (6,4,'Sprzedaz'),
 (7,4,'Inne przychody'),
 (8,5,'Wynagrodzenia'),
 (9,5,'Materia�y') 
 
create table Fact_Dane(ID_Poz int, Wart money)

insert Fact_Dane values
 (6,1000),(7,100),(8,600),(9,300)
 
alter table Dim_Pozycje add Operator varchar(1)

alter table Dim_Pozycje add Formula varchar(200)

 