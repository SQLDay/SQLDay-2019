use AdventureWorks
GO 

DECLARE @hire_date_years TABLE
	(hire_date_year NVARCHAR(50));

INSERT INTO @hire_date_years
	(hire_date_year)
SELECT DISTINCT
	DATEPART(YEAR, Employee.HireDate)
FROM HumanResources.Employee;

DECLARE @sql_command NVARCHAR(MAX);
SELECT @sql_command = '
CREATE OR ALTER VIEW dbo.v_job_title_year_summary
WITH SCHEMABINDING
AS
SELECT
	JobTitle,'

SELECT @sql_command = @sql_command + '
[' + hire_date_year + '], '
FROM @hire_date_years;

SELECT @sql_command = SUBSTRING(@sql_command, 1, LEN(@sql_command) - 1);

SELECT @sql_command = @sql_command + '
FROM
(	SELECT
		Employee.BusinessEntityID,
		Employee.JobTitle,
		DATEPART(YEAR, Employee.HireDate) AS HireDate_Year
	FROM HumanResources.Employee
) EMPLOYEE_DATA
PIVOT
(	COUNT(BusinessEntityID)
	FOR HireDate_Year IN (';

SELECT @sql_command = @sql_command + '[' + hire_date_year + '], '
FROM @hire_date_years;

SELECT @sql_command = SUBSTRING(@sql_command, 1, LEN(@sql_command) - 1);

SELECT @sql_command = @sql_command + '	)) PIVOT_DATA';

PRINT @sql_command;
EXEC sp_executesql @sql_command;
GO







--Zobaczmy czy widok pokazuje dane

SELECT
	*
FROM dbo.v_job_title_year_summary






--Zmodyfikujmy dane

UPDATE HumanResources.Employee
SET HireDate = '1/1/2016'
WHERE BusinessEntityID = 282

UPDATE HumanResources.Employee
SET HireDate = '1/1/2017'
WHERE BusinessEntityID IN (260, 285)




--Zobaczmy czy widok pokazuje dane

SELECT
	*
FROM dbo.v_job_title_year_summary



--Zbudujmy ponownie nasz widok



DECLARE @hire_date_years TABLE
	(hire_date_year NVARCHAR(50));

INSERT INTO @hire_date_years
	(hire_date_year)
SELECT DISTINCT
	DATEPART(YEAR, Employee.HireDate)
FROM HumanResources.Employee;

DECLARE @sql_command NVARCHAR(MAX);
SELECT @sql_command = '
CREATE OR ALTER VIEW dbo.v_job_title_year_summary
WITH SCHEMABINDING
AS
SELECT
	JobTitle,'

SELECT @sql_command = @sql_command + '
[' + hire_date_year + '], '
FROM @hire_date_years;

SELECT @sql_command = SUBSTRING(@sql_command, 1, LEN(@sql_command) - 1);

SELECT @sql_command = @sql_command + '
FROM
(	SELECT
		Employee.BusinessEntityID,
		Employee.JobTitle,
		DATEPART(YEAR, Employee.HireDate) AS HireDate_Year
	FROM HumanResources.Employee
) EMPLOYEE_DATA
PIVOT
(	COUNT(BusinessEntityID)
	FOR HireDate_Year IN (';

SELECT @sql_command = @sql_command + '[' + hire_date_year + '], '
FROM @hire_date_years;

SELECT @sql_command = SUBSTRING(@sql_command, 1, LEN(@sql_command) - 1);

SELECT @sql_command = @sql_command + '	)) PIVOT_DATA';

PRINT @sql_command;
EXEC sp_executesql @sql_command;
GO






--Zmodyfikujmy dane

UPDATE HumanResources.Employee
SET HireDate = '1/1/2013'
WHERE BusinessEntityID = 282

UPDATE HumanResources.Employee
SET HireDate = '1/1/2014'
WHERE BusinessEntityID IN (260, 285)