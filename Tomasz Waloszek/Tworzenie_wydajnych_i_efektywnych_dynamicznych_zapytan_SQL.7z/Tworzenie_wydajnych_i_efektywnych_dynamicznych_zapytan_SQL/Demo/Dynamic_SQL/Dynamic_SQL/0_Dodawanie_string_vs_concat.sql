USE AdventureWorks
GO 


-- ��czenie string
DECLARE @schema VARCHAR(25) = NULL;
DECLARE @table VARCHAR(25) = 'Person';
DECLARE @sql VARCHAR(MAX);

SET @sql = 'SELECT COUNT(*) ' + 'FROM ' +  @schema + '.' + @table;
select @sql;

SET @sql = 'SELECT COUNT(*) ' + 'FROM ' +  ISNULL(@schema, 'Person') + '.' + @table;
select @sql;

SET @sql = 'SELECT COUNT(*) ' + 'FROM ' +  CASE WHEN @schema IS NULL THEN 'Person' ELSE @schema END + '.' + @table;
select @sql;
GO


--concat

DECLARE @schema VARCHAR(25) = 'Person';
DECLARE @table VARCHAR(25) = 'Person';
DECLARE @sql VARCHAR(MAX);

SET @sql = CONCAT ('SELECT COUNT(*) ', 'FROM ', @schema, '.', @table);
select @sql;
GO