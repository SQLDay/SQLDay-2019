--2 Regression model
--test the correlation between age and number of failures. Predict how many device will fail at a certain age.
USE PredictiveMaintenance;
GO

SELECT AgeMonth, TotFailure FROM dbo.vw_ProductFailureCountAge ORDER BY AgeMonth;

/***********************************************************************************************************************************
Calculation of correlation coefficient using cor function. 
We want to find the correlation between the age and failures, i.e. the strengh and the sign of this association.
************************************************************************************************************************************/
EXEC sys.sp_execute_external_script
	@language = N'R'
	,@script = N'
		fail_tbl <- InputDataSet
		OutputDataSet <- data.frame(cor(fail_tbl$TotFailure, fail_tbl$AgeMonth))
		'
	,@input_data_1 = N'SELECT AgeMonth, TotFailure FROM dbo.vw_ProductFailureCountAge'
WITH RESULT SETS((cor_coeff decimal(8,2)));
GO

/**************************************************************************************************************************************************
Linear regression models are fitted in RevoScaleR using the rxLinMod function. The R object returned by rxLinMod includes the estimated model 
coefficients and the call used to generate the model, together with other information that allows RevoScaleR to recompute the model. 
The first argument to rxLinMod is the formula parameter, which defines failures as dependent on age.
The input data is stored in the variable CountProductFailure, which is populated by the SQL query. 
*****************************************************************************************************************************************************/
IF EXISTS (SELECT * FROM sys.procedures WHERE name = N'usp_linear_model' AND schema_id = 1)
DROP PROCEDURE dbo.usp_linear_model;
GO

CREATE PROCEDURE dbo.usp_linear_model
AS 
BEGIN
	EXEC sys.sp_execute_external_script
	@language = N'R'
	, @script = N'
		form <- TotFailure ~ AgeMonth
		FailLinMod <- rxLinMod(form, data = sqlData)
		tmodel <- data.frame(payload = as.raw(serialize(FailLinMod, connection = NULL)));'
	, @input_data_1 = N'SELECT AgeMonth, TotFailure FROM dbo.vw_ProductFailureCountAge'
	, @input_data_1_name = N'sqlData'
	, @output_data_1_name = N'tmodel'
	WITH RESULT SETS((model varbinary(max)));
END
GO


--Create a table to store the output every time the model is processed
--The output of an R package that creates a model is usually a binary object; therefore we create a table with a column of varbinary type.
IF EXISTS (SELECT * FROM sys.tables WHERE name = N'FailureAge_model' AND schema_id = 1)
DROP TABLE dbo.FailureAge_model;

CREATE TABLE dbo.FailureAge_model(
	id INT IDENTITY(1,1) PRIMARY KEY, 
    model_type varchar(30) not null DEFAULT('rxLinModel'),
	execution_time datetime2 DEFAULT(CURRENT_TIMESTAMP),
    model_output varbinary(max) not null
	);

TRUNCATE TABLE dbo.FailureAge_model;

--Populate the model table
INSERT INTO dbo.FailureAge_model(model_output)
EXEC dbo.usp_linear_model;

--What there is in the table?
SELECT * FROM dbo.FailureAge_model;

/*******************************************************************************************************
Use the model. Get score, predict and plot
The question is: How many device will fail for a due age? How the relationship is between Age and Failure?
To get the answer: 
-Select the model you want from trained table
-Pass new input data in the form of a table
-Call an R prediction function that is compatible with the model; in this case rxPredict as it is part of the RevoScaleR package.
*********************************************************************************************************/

--Create a new table to pass some test data to the model
IF EXISTS (SELECT * FROM sys.tables WHERE name = N'AgeTestData' AND schema_id = 1)
DROP TABLE dbo.AgeTestData;
GO
CREATE TABLE dbo.AgeTestData (
	AgeMonth INT,
	TotFailure INT 
);
GO

--Let's evaluate 6 months periods
INSERT INTO dbo.AgeTestData(AgeMonth)
VALUES(6),(12),(24),(36),(48),(60);

DECLARE @tmodel varbinary(max) = (SELECT model_output FROM dbo.FailureAge_model WHERE id = 5);
EXEC sp_execute_external_script
	@language = N'R'
	, @script = N'
			current_model <- unserialize(as.raw(tmodel));
			pass <- data.frame(T_AgeData);
			predicted.fail <- rxPredict(current_model,pass);
			str(predicted.fail);
			OutputDataSet <- cbind(pass, ceiling(predicted.fail));
			'
	, @input_data_1 = N'SELECT AgeMonth FROM [dbo].[AgeTestData]'
	, @input_data_1_name = N'T_AgeData'
	, @params = N'@tmodel varbinary(max)'
	, @tmodel = @tmodel
WITH RESULT SETS (([AgeMonth] INT, [Predicted_Failure] INT));

/************************************************************************************************************************************************************
Create an R plot of the model.
It is not possible to display directly in Management Studio a plot generated by R. A possible workaround is to redirect the output as an image to a file. 
Alternatively, it is possible to save the the serialized binary plot object into a table and query it with an appropriate tool, such as Reporting Services
************************************************************************************************************************************************************/
EXECUTE sp_execute_external_script
 @language = N'R'
 , @script = N'
     imageDir <- ''C:\\temp\\Rplot'';
     image_filename = tempfile(pattern = "plot_", tmpdir = imageDir, fileext = ".jpg")
     print(image_filename);
     jpeg(filename=image_filename,  width=600, height = 800);
     print(plot(TotFailure~AgeMonth, data=InputDataSet, xlab="Product age", ylab="Tot failure", main = "Product Age vs Tot Failure - trained model"));
     abline(lm(TotFailure~AgeMonth, data = InputDataSet));
     dev.off();
     OutputDataSet <- data.frame(data=readBin(file(image_filename, "rb"), what=raw(), n=1e6));
     '
  , @input_data_1 = N'SELECT AgeMonth, TotFailure FROM dbo.vw_ProductFailureCountAge'
  WITH RESULT SETS ((plot varbinary(max)));
 

/************************************************************************************************************************************************************
Create a R plot for single component with regression line, using ggplot.
************************************************************************************************************************************************************/
 EXECUTE sp_execute_external_script
 @language = N'R'
 , @script = N'
     library(ggplot2)
	 imageDir <- ''C:\\temp\\Rplot'';
     image_filename = tempfile(pattern = "plot_facet_wrap_", tmpdir = imageDir, fileext = ".jpg")
     print(image_filename);
     jpeg(filename=image_filename,  width=600, height = 800);
     
	 df_sql <- data.frame(ProductFailureCause)
	 p <- ggplot(data = df_sql, aes(x = AgeMonth, y = TotFailure)) + geom_point()  + geom_smooth(method=''lm'',formula=y~x)
     fp <- p + facet_wrap(~ FailureDescription)
	 par(mar = c(0,0,0,0))
	 print(fp)
	 
     dev.off();
     OutputDataSet <- data.frame(data=readBin(file(image_filename, "rb"), what=raw(), n=1e6));
     '
  , @input_data_1 = N'
		SELECT FailureDescription, TotFailure, AgeMonth 
		FROM dbo.vw_ProductFailureCause 
		WHERE FailureDescription IN(''Brake'',''Chain'',''Frame'',''Gear'',''Pedal'',''Tyre'');
	'
	, @input_data_1_name = N'ProductFailureCause'
WITH RESULT SETS ((plot varbinary(max)));