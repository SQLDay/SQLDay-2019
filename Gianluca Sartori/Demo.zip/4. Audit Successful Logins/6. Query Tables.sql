SELECT TOP(3) *
FROM TOOLS.dbo.AuditLogin_Staging
ORDER BY event_date DESC


SELECT TOP(3) *
FROM TOOLS.dbo.AuditLogin
