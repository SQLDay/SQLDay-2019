USE AdventureWorks2012_HeavyLoad
GO

DECLARE @count int = 1;

WHILE @count <= 1000
BEGIN
	DECLARE @sql nvarchar(max) =
		N'ALTER TABLE dbo.Product' + CAST(@count AS nvarchar(20)) + ' DISABLE CHANGE_TRACKING'
	EXEC @sql;
	SET @sql = N'DROP TABLE dbo.Product' + CAST(@count AS nvarchar(20));
	EXEC @sql;

	SET @count += 1;
END 
GO

ALTER DATABASE AdventureWorks2012_HeavyLoad
	SET CHANGE_TRACKING = OFF  
GO
