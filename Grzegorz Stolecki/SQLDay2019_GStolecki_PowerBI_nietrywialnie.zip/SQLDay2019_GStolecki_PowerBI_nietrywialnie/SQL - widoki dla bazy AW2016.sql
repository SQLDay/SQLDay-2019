create view vCustomers as
select
	C.CustomerKey,
	C.LastName + ' ' + C.FirstName Name,
	C.EnglishEducation Education,
	C.EnglishOccupation Occupation,
	C.Gender Gender,
	C.EmailAddress Email,
	C.YearlyIncome,
	G.City,
	G.StateProvinceName Province,
	G.EnglishCountryRegionName Country
from DimCustomer C join DimGeography G
     on C.GeographyKey = G.GeographyKey
go

create view vProducts as
select
	P.ProductKey,
	P.EnglishProductName Name,
	P.Color,
	P.Class,
	P.ModelName,
	S.EnglishProductSubcategoryName Subcategory,
	C.EnglishProductCategoryName Category,
	P.ListPrice
from DimProduct P left join DimProductSubcategory S
  on P.ProductSubcategoryKey = S.ProductSubcategoryKey
  left join DimProductCategory C
  on s.ProductCategoryKey = c.ProductCategoryKey
go

create view vDate as 
select
	D.CalendarYear Year,
	D.CalendarQuarter Quarter,
	D.DayNumberOfWeek DayOfWeekNr,
	D.EnglishDayNameOfWeek DayOfWeek,
	D.MonthNumberOfYear MonthNr,
	D.EnglishMonthName Month,
	D.FullDateAlternateKey Date
from DimDate D
go

create view vInternetSales as
select
	F.CustomerKey,
	F.ProductKey,
	F.OrderDate,
	F.ShipDate,
	F.SalesAmount Sales,
	F.OrderQuantity Quantity,
	F.TotalProductCost,
	F.UnitPrice
from FactInternetSales F
go

create view vResellerSales as
select
	F.ProductKey,
	F.OrderDate,
	F.ShipDate,
	F.SalesAmount Sales,
	F.OrderQuantity Quantity,
	F.TotalProductCost,
	F.UnitPrice
from FactResellerSales F
go
