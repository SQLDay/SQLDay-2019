USE [TameTheBeast];
GO

CREATE TABLE dbo.TableSpaceUsed
(
	ID int not null identity(1,1)
	, DatabaseName varchar(128)
	, SchemaName varchar(128)
	, TableName varchar(128)
	, [Rows] bigint
	, ReservedKB bigint		  
	, DataKB bigint		
	, IndexSizeKB bigint		   
	, UnusedKB bigint
	, Collection_Time datetime not null default GETUTCDATE(),
	CONSTRAINT PK_TableSpaceUsed PRIMARY KEY CLUSTERED (ID)
)
GO

CREATE procedure dbo.sp_TableSpaceUsed
as
BEGIN

	SET NOCOUNT ON;

	CREATE TABLE #Results
	(
	  DatabaseName varchar(128)
	, SchemaName varchar(128)
	, TableName varchar(128)
	, [Rows] bigint
	, ReservedKB bigint		  
	, DataKB bigint		
	, IndexSizeKB bigint		   
	, UnusedKB bigint
	)

	DECLARE @dbname varchar(128);
	DECLARE @sqlQuery nvarchar(4000);
 
	DECLARE dbcursor CURSOR FOR SELECT name FROM sys.databases WHERE [state] = 0 AND [name] <> 'tempdb'; -- only online databases
 
	OPEN dbcursor;
	FETCH NEXT FROM dbcursor INTO @dbname;
 
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @sqlQuery = ' 

	use [' + @dbname + ']

	; WITH Res AS (
		SELECT
		  OBJECT_SCHEMA_NAME(ps.[object_id]) AS SchemaName
		, OBJECT_NAME(ps.[object_id]) AS ObjectName
		, SUM (
			CASE
				WHEN (ps.index_id < 2) THEN row_count
				ELSE 0
			END
		) AS [Rows]
		, SUM (CAST(ps.reserved_page_count as bigint) ) AS [ReservedPages]
		, SUM (
			CASE
				WHEN (ps.index_id < 2) THEN (ps.in_row_data_page_count + ps.lob_used_page_count + ps.row_overflow_used_page_count)
				ELSE 0
			END
		) AS [Pages]
	,   SUM (cast(used_page_count as bigint)) AS [UsedPages]
		FROM sys.dm_db_partition_stats ps
		WHERE OBJECT_SCHEMA_NAME(ps.[object_id]) <> ''sys''
		GROUP BY ps.[object_id]
	)
	INSERT #Results
	SELECT
	  DB_NAME() AS DatabaseName
	, Res.SchemaName
	, Res.ObjectName
	, Res.[Rows]
	, Res.[ReservedPages]*8 AS [ReservedKB]
	, Res.[Pages]*8 AS [DataKB]
	, CASE WHEN [UsedPages] > [Pages] THEN ([UsedPages] - [Pages])*8 ELSE 0 END AS [IndexSizeKB]
	, CASE WHEN [ReservedPages] > [UsedPages] THEN ([ReservedPages] - [UsedPages])*8 ELSE 0 END AS [UnusedKB]
	FROM Res

	';

	exec sp_executesql @sqlQuery;

	FETCH NEXT FROM dbcursor INTO @dbname;
	END

	CLOSE dbcursor;
	Deallocate dbcursor;

	insert into dbo.TableSpaceUsed (DatabaseName, SchemaName, TableName, [Rows], ReservedKB, DataKB, IndexSizeKB, UnusedKB)
	SELECT
	  DatabaseName
	, SchemaName
	, TableName
	, [Rows]
	, ReservedKB  
	, DataKB
	, IndexSizeKB   
	, UnusedKB
	from #Results
	ORDER BY DatabaseName, SchemaName, TableName


	DROP TABLE #Results;
END
GO


USE [msdb]
GO


BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DatabaseTableSizeMonitoring', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'exec sp_TableSpaceUsed', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.sp_TableSpaceUsed', 
		@database_name=N'TameTheBeast', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run every 1 day', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190508, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'b942aa89-b10b-40c8-9df5-8aa3a82802d8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO



/*
EXEC msdb.dbo.sp_start_job @job_name = 'DatabaseTableSizeMonitoring' 
GO

SELECT * FROM TameTheBeast.dbo.TableSpaceUsed;
GO
--*/