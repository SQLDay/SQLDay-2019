--1 Descriptive statistics with RevoScaleR
USE PredictiveMaintenance;
GO

--Enable external scrips
EXEC sp_configure  'external scripts enabled', 1
RECONFIGURE WITH OVERRIDE

--Starting dataset
SELECT * FROM dbo.vw_ProductFailure; 


/**********************************************************************************************************************************
Summary statistics functions are available from RevoScaleR package to give some measures and variability about the dataset. 
Invoking function rxSummary()one gets the most common: Mean, median, mode, min, max, range, quartiles, etc�
**********************************************************************************************************************************/
EXEC sp_execute_external_script
	@language =N'R',
	@script=N'
		library(RevoScaleR)
		pf <-InputDataSet
		summary <- rxSummary(~., pf, summaryStats = c("Mean", "StdDev", "Min", "Max", "Sum","ValidObs"))
		OutputDataSet <- summary$sDataFrame',
	@input_data_1 =N'
		SELECT ProductionDate, FailureDate, COUNT(*) AS Tot    
		FROM dbo.vw_ProductFailure
		GROUP BY ProductionDate, FailureDate
	 '
 WITH RESULT SETS ((
	VariableName nvarchar(max),
	[Mean] nvarchar(100),
	[StdDev] nvarchar(100),
	[Min] nvarchar(100),
	[Max] nvarchar(100),
	[Sum] nvarchar(100),
	[ValidObs] nvarchar(100)
	));
GO


--statistics for failure description is not available natively as it is not an integer. 
--these kind of variables are called categorical variables in R. 
--we can perform cross tabulation (calculating the relationship between two or more variables) using rxCrossTabs
EXEC sp_execute_external_script
	 @language = N'R'
	,@script = N'
			library(RevoScaleR)
			inpdst <- InputDataSet
			crosstab <- rxCrossTabs(TotFailure ~ ProductSubcategoryName,  inpdst, means=TRUE)
			failure <- c("Road Bikes","Mountain Bikes","Touring Bikes")
			OutputDataSet <- data.frame(crosstab$sums, failure)
			'
	,@input_data_1 = N'
			SELECT ProductSubcategoryName, TerritoryName, COUNT(*) AS TotFailure 
			FROM dbo.vw_ProductFailure
			GROUP BY ProductSubcategoryName, TerritoryName'
WITH RESULT SETS
	((  
		 TotFailureSUM INT
		,FailureDescription NVARCHAR(100)
	 ));
