﻿CREATE SCHEMA [data]
    AUTHORIZATION [dbo];

