DECLARE @spid int = 59

SELECT percent_complete, logical_reads*8/1024 AS Reads_MB, * 
FROM sys.dm_exec_requests 
WHERE session_id = @spid

