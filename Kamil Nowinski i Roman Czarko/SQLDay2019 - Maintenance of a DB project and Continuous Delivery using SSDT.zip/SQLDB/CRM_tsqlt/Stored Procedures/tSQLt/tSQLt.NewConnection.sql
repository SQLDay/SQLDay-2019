﻿CREATE PROCEDURE [tSQLt].[NewConnection]
@command NVARCHAR (MAX) NULL
AS EXTERNAL NAME [tSQLtCLR].[tSQLtCLR.StoredProcedures].[NewConnection]

