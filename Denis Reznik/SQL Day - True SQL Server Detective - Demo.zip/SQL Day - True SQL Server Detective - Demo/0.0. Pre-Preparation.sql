ALTER DATABASE AdventureWorks2012_HeavyLoad 
	SET CHANGE_TRACKING = ON (CHANGE_RETENTION = 1 MINUTES, AUTO_CLEANUP = OFF) 
GO

DECLARE @count int = 1;

WHILE @count <= 100000
BEGIN
	DECLARE @sql nvarchar(max) =
		N'SELECT * INTO dbo.Product' + CAST(@count AS nvarchar(20)) + ' FROM [Production].[Product];';
	EXEC(@sql);
	SET @sql = N'ALTER TABLE dbo.Product' + CAST(@count AS nvarchar(20)) + ' ADD  CONSTRAINT [PK_Product' + CAST(@count AS nvarchar(20)) + '_ProductID] PRIMARY KEY ([ProductID])';
	EXEC(@sql);
	SET @sql = N'ALTER TABLE dbo.Product' + CAST(@count AS nvarchar(20)) + ' ENABLE CHANGE_TRACKING';
	EXEC(@sql);

	SET @count += 1;
END 
GO

-- 24 GB