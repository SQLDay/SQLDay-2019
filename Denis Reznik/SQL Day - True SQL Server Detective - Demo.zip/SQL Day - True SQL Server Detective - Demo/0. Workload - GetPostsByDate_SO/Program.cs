﻿using Dapper;
using System.Configuration;
using System.Data.SqlClient;

namespace GetPostsByDate_SO
{
    class Program
    {
        static void Main(string[] args)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["SO"].ConnectionString;
            var query = @"
SELECT p.CreationDate, p.Title AS PostTitle, u.DisplayName AS UserName
FROM Posts p
LEFT JOIN Users u
    ON p.OwnerUserId = u.Id
WHERE CAST(p.CreationDate as date) BETWEEN DATEFROMPARTS(@year, @month, 1) 
	AND EOMONTH(DATEFROMPARTS(@year, @month, 1))
ORDER BY p.CreationDate DESC";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Query(query, new { year = args[0], month = args[1] });
            }
        }
    }
}
