USE [TameTheBeast];
GO

CREATE PROCEDURE dbo.sp_Triage (
@mode int = 1
			-- 1 = Run sp_WhoIsActive only
			-- 2 = Run sp_WhoIsActive and sp_BlitzFirst
			-- 3 = Run sp_BlitzCache, sp_Blitz, sp_BlitzIndex
			-- 4 = Run all
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @table NVARCHAR(max);
	DECLARE @seconds_delta INT;
	IF (@mode < 3) SET @seconds_delta = 5 ELSE SET @seconds_delta = 10;

	DECLARE @tableFound BIT = 0
	DECLARE @Parameter NVARCHAR(MAX) = '@bFound BIT OUTPUT'

	-- determine the version and addition of the server
	DECLARE @schema NVARCHAR(256);
	DECLARE @database NVARCHAR(256);
	SET @schema = 'dbo'
	SET @database = DB_NAME() 
 
 

	IF ( @mode IN (1,2,4) )
	BEGIN

		-- Check #1 sp_whoIsActive.  Checks blocks and waits
		SET @table = @database + '.' + @schema + '.' + 'WhoIsActive'

		-- we need to create the table if it doesn't already exist
		DECLARE @statement NVARCHAR(MAX) = 'If exists (select * from ' + @database + '.sys.tables where type = ''U'' and name = ''whoIsActive'' and [schema_id] = SCHEMA_ID(''' + @schema + '''))'
		+ 'Set @bFound = 1' +
		' Else Set @bFound = 0'

		EXECUTE dbo.sp_executesql @statement, @Parameter, @tableFound OUTPUT

		IF (@tableFound = 0)
			begin

				DECLARE @schemaname varchar(max)

				exec dbo.sp_WhoIsActive 
					@get_plans = 1, 
					@get_locks = 1,
					@get_task_info = 2,
					@get_additional_info = 1,
					@find_block_leaders = 1,
					@delta_interval = @seconds_delta,
					@sort_order = '[blocked_session_count] DESC',
					@destination_table  = @table,
					@return_schema  = 1,
					@schema  = @schemaname OUTPUT,
					@get_outer_command = 1,
					@get_avg_time = 1

				SET @table = REPLACE(@schemaname, '<table_name>', (@database + '.'+ @schema + '.whoIsActive'))
				exec(@table)
			end

		SET @table = @database + '.' + @schema + '.' + 'whoIsActive'

		exec dbo.sp_WhoIsActive 
			@get_plans = 1, 
			@get_locks = 1,
			@get_task_info = 2,
			@get_additional_info = 1,
			@find_block_leaders = 1,
			@delta_interval = @seconds_delta,
			@sort_order = '[blocked_session_count] DESC',
			@destination_table  = @table,
			@get_outer_command = 1,
			@get_avg_time = 1

		-- when writing to a database table, sp_WhoIsActive doesn't return results to the screen, so get the last days entries from the table	  
		exec ('select * from '+ @table +' where collection_time >= (select max(collection_time) from '+ @table +' with(nolock)) order by collection_time desc, blocked_session_count desc')

		RAISERROR (N'dbo.sp_whoIsActive complete',0,1) WITH NOWAIT;

	END


	IF ( @mode IN (2,4) )
	BEGIN

		-- Check #2 sp_BlitzFirst.  Checks for maintenance tasks, resource problems
		SET @table = 'BlitzFirst'

		exec dbo.sp_BlitzFirst 
			@seconds = @seconds_delta, 
			@expertmode = 1,
			@OutputDatabaseName = @database,
			@OutputSchemaName = @schema ,
			@OutputTableName = @table,
			@OutputTableNameFileStats = 'FileStats',
			@OutputTableNamePerfmonStats = 'PerfmonStats',
			@OutputTableNameWaitStats = 'WaitStats'

		RAISERROR (N'dbo.sp_BlitzFirst complete',0,1) WITH NOWAIT;
	END


	IF ( @mode IN (3,4) )
	BEGIN

		-- Check #3 sp.BlitzCache.  Finds cached plans that are not optimal.
		SET @table = 'BlitzCache'

		exec dbo.sp_BlitzCache 
			@help = 0,
			@top = 50,
			@sortOrder = 'CPU',
			@usetriggersanyway  = NULL,
			@exporttoexcel  = 0,
			@ExpertMode  = 1,
			@outputdatabasename = @database ,
			@outputschemaname = @schema,
			@outputtablename = @table ,
			@configurationdatabasename = NULL ,
			@configurationschemaname = NULL ,
			@configurationtablename = NULL ,
			@durationfilter = NULL ,
			@hidesummary  = 0 ,
			@ignoresystemdbs = 1 ,
			@onlyqueryhashes = NULL ,
			@ignorequeryhashes = NULL ,
			@onlysqlhandles = NULL ,
			@queryfilter = 'ALL' ,
			@databasename = NULL ,
			@reanalyze = 0 
			--,@wholecache = 0

		RAISERROR (N'dbo.sp_BlitzCache complete',0,1) WITH NOWAIT;


		-- Check #4 sp_Blitz.  Checks for problems with server configuration
		SET @table = 'Blitz'

		exec dbo.sp_Blitz
			@CheckUserDatabaseObjects = 1 ,
			@CheckProcedureCache = 1 ,
			@OutputProcedureCache = 1 ,
			@CheckServerInfo = 1 ,
			@OutputDatabaseName = @database,
			@OutputSchemaName = @schema,
			@OutputTableName = @table

		RAISERROR (N'dbo.sp_Blitz complete',0,1) WITH NOWAIT;



		-- Check #5 sp_BlitzIndex.  Checks for index issues
		exec dbo.sp_BlitzIndex
			@Mode = 0  /*0=diagnose, 1=Summarize, 2=Index Usage Detail, 3=Missing Index Detail*/

		RAISERROR (N'dbo.sp_BlitzIndex complete',0,1) WITH NOWAIT;
	END

END
GO
