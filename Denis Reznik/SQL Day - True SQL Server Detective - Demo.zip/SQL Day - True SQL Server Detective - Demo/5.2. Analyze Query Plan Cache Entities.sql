USE StackOverflow
GO

SELECT t.text, p.query_plan, s.query_hash, s.query_plan_hash, * FROM sys.dm_exec_query_stats s
CROSS APPLY sys.dm_exec_sql_text(s.sql_handle) t
CROSS APPLY sys.dm_exec_query_plan(s.plan_handle) p
WHERE t.text LIKE '%EOMONTH%'
	AND t.text NOT LIKE '%exec[_]query[_]plan%'
GO

