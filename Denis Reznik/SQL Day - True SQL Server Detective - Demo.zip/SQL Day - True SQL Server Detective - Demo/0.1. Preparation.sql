USE StackOverflow
GO

CREATE OR ALTER PROCEDURE GetPostsByMonth
	@year int,
	@month int
AS
BEGIN
	SELECT p.CreationDate, p.Title AS PostTitle, u.DisplayName AS UserName
	FROM Posts p
	LEFT JOIN Users u
		ON p.OwnerUserId = u.Id
	WHERE CAST(p.CreationDate as date) BETWEEN DATEFROMPARTS(@year, @month, 1) 
		AND EOMONTH(DATEFROMPARTS(@year, @month, 1))
	ORDER BY p.CreationDate DESC
END
GO

--EXEC GetPostsByMonth 2014, 3
--GO


--EXEC GetPostsByMonth 2008, 7
--GO

CREATE DATABASE VeryImportantDatabase
GO

USE VeryImportantDatabase
GO

CREATE TABLE Numbers (Number int)
GO

USE master
GO

WAITFOR DELAY '00:00:10'
GO

USE [master]
GO
DROP DATABASE VeryImportantDatabase
GO

USE [master]
GO
ALTER DATABASE [AdventureWorks2012_HeavyLoad] SET CHANGE_TRACKING (AUTO_CLEANUP = ON, CHANGE_RETENTION = 1 MINUTES)
GO