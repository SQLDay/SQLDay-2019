USE master;
GO

DROP DATABASE IF EXISTS TameTheBeast;
GO

CREATE DATABASE TameTheBeast;
GO

/* Start SQL Server Agent */