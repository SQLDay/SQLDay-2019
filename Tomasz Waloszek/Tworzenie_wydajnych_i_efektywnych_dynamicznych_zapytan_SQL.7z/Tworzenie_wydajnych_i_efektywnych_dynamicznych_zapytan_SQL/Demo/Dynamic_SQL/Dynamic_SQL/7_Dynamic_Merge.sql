USE AdventureWorks
GO 

CREATE OR ALTER PROCEDURE dbo.usp_merge_danych

@Tabela nvarchar(100),
@Debug BIT = 0 

AS

	-- wyznaczenie nazwy tabeli docelowej 

	DECLARE @Tabela_docelowa NVARCHAR(MAX) = (select '[dbo]' + SUBSTRING(@tabela, CHARINDEX('.', @tabela), LEN(@tabela)))

	--Zapisujemy do #tabeli dane o kolumnach do MERGE

	select 
		QUOTENAME(COLUMN_NAME) AS Nazwa_kolumny 
		INTO #kolumny_merge
	from INFORMATION_SCHEMA.COLUMNS
	where 
		QUOTENAME(TABLE_SCHEMA) = SUBSTRING(@tabela,1, CHARINDEX('.', @tabela)-1) 
		AND QUOTENAME(TABLE_NAME) = SUBSTRING(@tabela, CHARINDEX('.', @tabela)+1, LEN(@tabela)) 
	INTERSECT 
	select 
		QUOTENAME(COLUMN_NAME) AS Nazwa_kolumny 
	from STG.INFORMATION_SCHEMA.COLUMNS
	where 
		QUOTENAME(TABLE_SCHEMA) = SUBSTRING(@Tabela_docelowa,1, CHARINDEX('.', @Tabela_docelowa)-1) 
		AND QUOTENAME(TABLE_NAME) = SUBSTRING(@Tabela_docelowa, CHARINDEX('.', @Tabela_docelowa)+1, LEN(@Tabela_docelowa)) 


	-- wyznaczenie listy kolumn do MERGE
	DECLARE @kolumny_merge nvarchar(max) = (
	SELECT CONVERT(nVARCHAR(MAX), STUFF(

	(SELECT ', ' + Nazwa_kolumny FROM #kolumny_merge
	FOR XML PATH('')),1,1,'')
	))
 

	--wyznaczenie kolumn klucza g��wnego w tabeli �r�d�owej
	DECLARE @kolumny_PK nVARCHAR(MAX) = (

	select 

		substring(column_names, 1, len(column_names)-3) 
	from sys.tables tab
		left outer join sys.indexes pk
			on tab.object_id = pk.object_id 
			and pk.is_primary_key = 1
	   cross apply (select CONCAT('[trg].',QUOTENAME(col.[name]), ' = ','[src].',QUOTENAME(col.[name]), ' AND ')
						from sys.index_columns ic
							inner join sys.columns col
								on ic.object_id = col.object_id
								and ic.column_id = col.column_id
						where ic.object_id = tab.object_id
							and ic.index_id = pk.index_id
								order by col.column_id
								for xml path ('') ) D (column_names)
	where 
		CONCAT(QUOTENAME( schema_name(tab.schema_id)),'.', QUOTENAME(tab.[name])) = @tabela
		)



	--Wykonanie merge do bazy STG

	DECLARE @MERGE_SQL VARCHAR(MAX) = 
	';MERGE STG.'+ @Tabela_docelowa + '  AS trg
		USING (
			SELECT ' + @kolumny_merge + ' FROM ' + @Tabela + CHAR(13)+ CHAR(10)
		+   ' ) AS src
			ON (' + CHAR(13)+ CHAR(10)+ @kolumny_PK + + CHAR(13)+ CHAR(10)+
			') 
		WHEN MATCHED  THEN
		UPDATE SET '
		 +
				  (
					  SELECT CONVERT(VARCHAR(MAX),
									 STUFF(
									 (
										 SELECT ', trg.' + Nazwa_kolumny + ' = src.' + Nazwa_kolumny
										 FROM #kolumny_merge
										 FOR XML PATH('') ), 1, 1, '')
									 ) -- wyznaczenie listy kolumn do update
				  ) + '
		
			WHEN NOT MATCHED THEN 
			INSERT (' + @kolumny_merge + ') 
			VALUES
			(' +
				  (
					  SELECT CONVERT(VARCHAR(MAX),
									 STUFF(
									 (
										 SELECT ', src.' + Nazwa_kolumny
										 FROM #kolumny_merge
										 FOR XML PATH('')), 1, 1, '' )
									 )
				  ) -- kolumn z Source
		   + ');';

		--Wykonanie kodu
		IF @Debug = 0 
		BEGIN
			Exec  (@MERGE_SQL)
								  
							
			If @@ERROR <> 0 GoTo ErrorHandler
				Set NoCount OFF
				Return(0)
	
				ErrorHandler:
				Return(@@ERROR)
		END

		IF @Debug = 1
			PRINT  @MERGE_SQL


GO










--***********************************************************************
--Testy


--Wyczy��my dane w naszej tabeli 

TRUNCATE TABLE STG.[dbo].[Product]
GO 

EXEC	[dbo].[usp_merge_danych]
		@Tabela = N'[Production].[Product]',
		@Debug = 1




TRUNCATE TABLE STG.[dbo].[Person]
GO 


EXEC	 [dbo].[usp_merge_danych]
		@Tabela = N'[Person].[Person]',
		@Debug = 0